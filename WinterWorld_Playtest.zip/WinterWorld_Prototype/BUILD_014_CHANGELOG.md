# Build 014 — M2 Forest Art Pass 4

## Implemented
- Reworked the three shared conifer species so they have visibly different structural profiles: dense tapered spruce, wider drooping cedar, and irregular open fir.
- Varied branch-whorl phase between levels, branch counts, branch lengths, droop, asymmetry, vertical placement, and the occasional missing branch to avoid repeated radial pinwheels.
- Added more varied forked branchlets and exposed twig tips, with independent needle-spray positions and lengths.
- Replaced the narrow conifer snow ribbons with broader, slightly deeper, uneven snow pillows that should read more clearly from normal player height while remaining open underneath and attached to the upper bough.
- Added a restrained cool moon-fill term for snow-colored surfaces in the existing material shader, making upper branch snow more readable without brightening the dark-green foliage by the same amount.

## Preserved
- Sakura trunk, branch, snow, and blossom meshes and all four grove placements are unchanged.
- Rocks, forest-floor scatter, path, snow shoulders, cabin, collision, stairs, controls, terrain following, graphics presets, FPS modes, fog, snowfall, and settings remain unchanged.

## Why this pass exists
- Build 013 user feedback confirmed trunk/branch detail was improved and sakura snow was more visible, but the conifer branch structure/silhouette checks were not accepted or fully reviewed. The user also requested further visual upgrades.
- Build 014 concentrates on the evergreen structures and the night-time visibility of their branch snow.

## Awaiting user testing
- Whether the three conifer forms now look less repetitive and more distinct.
- Whether branch lengths, spacing, forked twigs, and foliage read more naturally.
- Whether broader snow pillows are easier to see from ground level and remain attached.
- Whether the snow surface shading looks natural under the existing nighttime lighting.
- Performance on the user's PC in the denser forest views.

## Not final
These remain intermediate procedural evergreen meshes. They are not final hero assets. Detailed bark and needle textures, physically based material maps, dynamic shadows, ambient occlusion, and further art-directed tree modeling remain future M2 work.

## Validation results
- `node --check src/main.js`: passed.
- `node --check src/sakura_mesh_data.js`: passed.
- Mock WebGL2 initialization and one scheduled frame: passed.
- Static references and build metadata: passed.
- Final scene metrics and package integrity: recorded in this build's progress log after packaging.
- Actual browser/GPU visual rendering and target-PC FPS: not verified here; require user test.
