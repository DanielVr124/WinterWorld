# Winter World — Build 011 changelog

## M2 — Forest quality benchmark · Visual pass 1

Build 011 begins the first M2 art pass. It preserves the movement, collision, walkable cabin steps, graphics presets, frame-limit options, fog range, lantern positions, and accepted cabin geometry from Build 010.

### Forest vegetation
- Replaced the repeated low-sided cone-stack trees with three shared conifer forms: broad spruce, narrower cedar-like evergreen, and young understory tree.
- New tree meshes include gently curved tapered trunks, exposed tapered boughs, varied branch whorls, dense overlapping needle-foliage masses, and smaller individual needle sprays.
- Added continuous, irregular snow ribbons along the upper surfaces of boughs so snow reads as resting on branches rather than as separate floating discs.
- Added deterministic scale, rotation, and subtle tint variation so repeated instances do not look identical.
- Tree species are built once and GPU-instanced across the forest.

### Forest floor and composition
- Added young understory growth to fill gaps beneath the mature canopy.
- Added irregular vertex-colored rocks with snow accumulation on upward-facing surfaces; larger rocks receive collision volumes.
- Added a small number of fallen limbs partially buried in snow, positioned outside the intended path and cabin clearance zones.
- Added subtle per-vertex color variation to terrain, compacted path, and snow shoulders.
- Terrain normals now follow the terrain height gradient for more natural shading across the rolling snowfield.
- Added two-sided diffuse response for the thin foliage surfaces. Fine material variation is carried by vertex colors rather than expensive per-pixel noise.

### Diagnostics
- F3 now additionally reports total scene instances and estimated submitted triangle count. These are scene submission counts, not GPU timing measurements.

### Intentionally unchanged
- Player movement, mouse look, sprint, pointer lock, stair climbing, and existing cabin/tree/lantern collision behavior.
- Path centerline, path width, snow-shoulder placement, and their height functions.
- Cabin shape, roof, and sign; night sky, stars, snowfall motion, fog distances, lantern locations, frame-rate modes, and graphics preset settings.
- No new external runtime dependency or remote asset download is required.

### Quality status
This is the first procedural forest-art pass, not the final photorealistic benchmark. PBR textures, dynamic shadow mapping, ambient occlusion, hero-quality individual trees, detailed moss/icicles, and further lighting polish remain future M2 work. Performance on the target PC still needs user testing.
