# Winter World — Development Build 014

A Windows-friendly HTML/WebGL2 first-person winter-world prototype. Build 014 continues **M2 — The Quality Benchmark** by giving the evergreen species more distinct branching structures and making branch snow more visible at player height.

## Run the world

1. Extract the ZIP.
2. Open the `WinterWorld_Prototype` folder.
3. Double-click `index.html` in a current version of Chrome or Edge.
4. Click **Enter the World**.

If your browser blocks local-file rendering, open a Command Prompt in this folder and run `py -m http.server 8000` (or `python -m http.server 8000`), then visit `http://127.0.0.1:8000/`. The included `run.bat` opens the local HTML file in your default browser.

## Controls

- `W`, `A`, `S`, `D` or arrow keys: move
- Mouse: look around while pointer lock is active
- `Shift`: move faster
- `Esc`: release the mouse / close the settings panel
- Click the scene: capture the mouse again
- `E`: show the current development note
- `F3`: toggle live performance and player diagnostics

## Build 011 — M2 forest quality benchmark, pass 1

### Vegetation upgrade

- Replaced the simple cone-stack evergreen blockouts with three shared conifer meshes: broad spruce, narrow cedar-like evergreen, and young understory tree.
- Trees now have curved tapered trunks, exposed branching, varied branch whorls, overlapping needle-foliage masses, smaller needle sprays, and continuous snow ribbons resting along upper bough surfaces.
- Added deterministic size, rotation, and subtle tint differences between instances.
- Shared tree-species meshes are GPU-instanced to avoid issuing a separate draw call for each branch and needle cluster.

### Forest floor upgrade

- Added young tree growth to layer the space beneath the main canopy.
- Added irregular rocks with snow on upper surfaces; larger rocks have collision.
- Added a few fallen limbs partially embedded in snow, kept outside the intended path corridor.
- Added subtle per-vertex color breakup to the terrain, compacted path, and snow shoulders.
- Terrain normals now follow the underlying height variation rather than being uniformly vertical.
- Added two-sided foliage lighting; material variation is baked into vertex colors instead of expensive per-pixel noise.

### Diagnostics

Press `F3` for live FPS, estimated frame interval, JavaScript render CPU time, graphics preset, frame-limit mode, canvas resolution, player coordinates, ground height, blocked movement attempts, solid collider count, scene instance count, and estimated submitted triangle count. Build 011's source/runtime harness reports about 270 scene instances and 1.55 million submitted triangles across 12 instanced batches. CPU time is not a direct GPU timer.

## Existing functionality retained from M1

- First-person movement, mouse look, sprint, pointer lock, collision, sliding along obstacles, and ground following.
- Four climbable entry treads; the unfinished cabin interior remains blocked by the cabin wall.
- High, Balanced, and Performance graphics presets.
- 30 FPS, 60 FPS, and Unlocked app-side frame modes. Unlocked still follows browser/display frame scheduling.
- Night sky, stars, moon, snowfall, distance fog, and warm lanterns.

## Current project status

- **M1 — Technical Foundation: complete.** The user tested Build 010 and passed all five sections, including climbable stairs, ground following, graphics settings, diagnostics, and performance.
- **M2 — Quality Benchmark: in progress.** Build 011 introduced the first conifer/forest-floor pass. Build 012 added the source-derived sakura grove; the user accepted the blossoms and rocks but requested more snow and said the overall tree models still look low quality. Build 013 was reviewed: the user accepted the sakura branch/detail improvements but requested more overall visual upgrades and did not accept the conifer structure checks. Build 014 reworks the conifer species and their branch-snow readability; visual/performance review is pending.
- **M2 still ahead:** photorealistic materials, dynamic shadows, detailed hero vegetation/rocks, forest lighting refinement, bakery exterior/interior, and the first text-conversational NPC prototype.
- **Later systems:** dynamic footprints and snow deformation, persistent NPC memory, AI service integration, audio, weather simulation, save system, large-world generation and streaming.

## Testing workflow

All testing happens **in this ChatGPT conversation**. Each new build's checklist only covers code or content changed by that build, plus specific regressions that those changes could plausibly affect. Unchanged, already-verified features are not routinely retested.


## Build 012 — M2 Forest Art Pass 2

- Added a four-tree Japanese sakura grove using a reduced mesh derived from the project's detailed Snow Cherry Blossom Tree asset. The source's mature trunk/branch structure, buds, fine pedicels, snow geometry, and vertex colors are retained.
- Simplified the source mesh for the game and replaced tens of thousands of full flower objects with 5,859 instanced low-poly blossom placements per tree. The original 45 MB GLB is not included in the build.
- Refined conifer branch/needle density and replaced closed snow tubes with shallow open snow caps along upper boughs.
- Refined irregular snow-covered rocks and added smaller half-buried stone clusters.
- F3 now reports sakura mesh triangles and blossom instance counts.
- This remains an early M2 quality pass, not the final PBR/photorealistic asset and lighting pass.

## M2 — Current state

- Forest Art Pass 1: first conifer/understory/forest-floor upgrade (Build 011), reviewed by the user; tree/branch-snow/rock quality requires further iteration.
- Forest Art Pass 2: source-derived sakura grove, flower instances, and rock refinements (Build 012), reviewed by the user.
- Forest Art Pass 3: finer separate sakura snow mesh and improved sakura trunk/twig detail (Build 013), reviewed by the user.
- Forest Art Pass 4: three more distinct conifer structures, irregular whorl and branch variation, broader branch snow, and cool snow-surface fill lighting (Build 014), awaiting visual and target-PC performance testing.
- Remaining M2 work: final bark/needle/flower/snow material treatment, better forest lighting and shadows, hero vegetation/rock assets, forest composition polish, detailed bakery exterior/interior, and the first typed open-ended NPC prototype.

The M1 foundation remains complete from Build 010 user testing. Unchanged M1 systems are not included in routine later test checklists.


## Build 013 changes
- Sakura snow is now a separate, finer mesh so smaller authored deposits survive asset reduction and remain visible on the branches.
- The sakura trunk, pedicels, bark details, and buds retain more source geometry.
- Conifer branches have more irregular spacing, lengths, droop, and forked twigs to avoid repeated radial patterns.
- Blossom placement and the Build 012 flower mesh are unchanged.
- Build 013 remains an intermediate visual pass, not the final photorealistic asset set.

Testing is performed directly in the ChatGPT conversation. No standalone testing page is included.


## Build 013 — M2 Forest Art Pass 3

- Preserved more of the authored sakura trunk, branch stems, bark detail, and bud geometry.
- Separated the sakura snow deposits into their own higher-resolution mesh, using a 0.0075 m vertex-cluster reduction rather than the coarse Build 012 reduction.
- Expanded the snow shell 2.5% horizontally and offset it 4.5 mm along its original normals to make small branch deposits easier to see while keeping them close to the source surface.
- Kept Build 012's flower mesh and 5,859 blossom placements per tree unchanged because the user passed the blossom checks.
- Made conifer branches less evenly radial by varying branch angles, lengths and droop, increasing needle-spray spacing, and adding short forked side twigs.
- This is still an intermediate benchmark pass. It is not the final model set or final photorealistic treatment. Detailed PBR textures, dynamic shadows, ambient occlusion, and final forest lighting remain future work.

### Build 013 validation

- `node --check src/main.js`: passed.
- `node --check src/sakura_mesh_data.js`: passed.
- Mock WebGL2 harness: initialization and first frame passed.
- Mock scene metrics: 23,710 scene instances, 16 instanced batches, 5,406,222 submitted triangles, and 104 colliders.
- Sakura mesh: 267,812 body triangles and 76,308 snow-shell triangles per tree; 5,859 blossom instances per tree (23,436 across four trees).
- Mock-harness buffer uploads: about 22.35 MB; this is not a measurement of physical GPU memory.
- Actual target-PC browser rendering and FPS: awaiting user review.


## Build 014 — M2 Forest Art Pass 4

- Reworked spruce, cedar, and open-fir meshes to have distinct branch profiles instead of near-identical radial tiers.
- Added per-level phase shifts, irregular whorl counts, larger branch length/droop variance, asymmetric boughs, occasional gaps, additional forked branchlets, and less regular exposed twig tips.
- Widened and deepened the conifer snow pillows and added subtle irregular edges so they should be easier to see from normal walking height.
- Added restrained cool fill lighting for snow-colored surfaces under the existing night lighting.
- Preserved all sakura assets, blossom placement, rocks, path, cabin, lighting/fog system, movement/collision, graphics settings, and FPS modes.
- The conifers remain intermediate procedural models, not final photorealistic hero assets.

### Build 014 validation

- JavaScript syntax checks: passed.
- Mock WebGL2 initialization and one scheduled frame: passed.
- Scene metrics: recorded in `PROGRESS.md`.
- This mock test is not an actual browser visual render or target-PC GPU benchmark.
