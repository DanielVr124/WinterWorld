(() => {
  'use strict';
  const canvas = document.getElementById('world');
  const gl = canvas.getContext('webgl2', { antialias: true, alpha: false, powerPreference: 'high-performance' });
  const statusText = document.getElementById('statusText');
  const intro = document.getElementById('intro');
  const crosshair = document.getElementById('crosshair');
  const hudBottom = document.getElementById('hudBottom');
  const reticleLabel = document.getElementById('reticleLabel');
  const fpsLabel = document.getElementById('fpsLabel');
  const toast = document.getElementById('toast');
  if (!gl) {
    statusText.textContent = 'WEBGL2 NOT AVAILABLE';
    document.getElementById('rendererLabel').textContent = 'Unavailable';
    showToast('This browser or graphics driver does not expose WebGL2. Try updating your browser and GPU driver.');
    return;
  }

  const vertexSource = `#version 300 es
  precision highp float;
  layout(location=0) in vec3 aPosition;
  layout(location=1) in vec3 aNormal;
  layout(location=2) in vec3 aVertexColor;
  layout(location=3) in vec4 iModel0; layout(location=4) in vec4 iModel1; layout(location=5) in vec4 iModel2; layout(location=6) in vec4 iModel3;
  layout(location=7) in vec3 iColor; layout(location=8) in float iEmissive;
  uniform mat4 uProjection; uniform mat4 uView;
  out vec3 vWorld; out vec3 vNormal; out vec3 vColor; out float vEmissive;
  void main(){ mat4 model=mat4(iModel0,iModel1,iModel2,iModel3); vec4 world=model*vec4(aPosition,1.0); vWorld=world.xyz; vNormal=normalize(mat3(model)*aNormal); vColor=aVertexColor*iColor; vEmissive=iEmissive; gl_Position=uProjection*uView*world; }
  `;
  const fragmentSource = `#version 300 es
  precision highp float;
  in vec3 vWorld; in vec3 vNormal; in vec3 vColor; in float vEmissive;
  uniform vec3 uEye; uniform float uFogNear; uniform float uFogFar;
  uniform vec3 uLampPos[8]; uniform vec3 uLampColor[8]; uniform int uLampCount;
  out vec4 outColor;
  void main(){
    vec3 N=normalize(vNormal); vec3 L=normalize(vec3(-0.38,0.84,-0.34));
    float diffuse=max(dot(N,L),0.0);
    float hemi=0.5+0.5*N.y;
    // Fine variation is baked into shared vertex colors rather than sampled
    // per pixel, keeping the 1050 Ti target's fragment workload modest.
    float materialVariation=1.0;
    // Thin needle and foliage surfaces are rendered two-sided; a soft two-sided
    // diffuse term prevents back-facing leaf planes from becoming nearly black.
    float foliageMask=step(vColor.r,0.12)*step(0.08,vColor.g)*(1.0-step(0.27,vColor.g));
    float foliageDiffuse=max(diffuse,abs(dot(N,L))*0.66);
    float foliageLighting=0.48+0.20*hemi+0.32*foliageDiffuse;
    float surfaceLighting=mix(0.35+0.27*hemi+0.38*diffuse,foliageLighting,foliageMask);
    // Snow on the conifers needs to remain readable from the player's ground-level
    // view at night. A restrained cool moon-fill lifts snow surfaces without
    // washing out the darker needles or turning the whole forest blue-white.
    float snowMask=step(0.52,vColor.r)*step(0.66,vColor.g)*step(0.76,vColor.b);
    float snowLighting=0.62+0.17*hemi+0.34*diffuse;
    surfaceLighting=mix(surfaceLighting,snowLighting,snowMask*0.92);
    vec3 col=vColor*surfaceLighting*materialVariation;
    col += vColor*vEmissive;
    for(int i=0;i<8;i++){ if(i>=uLampCount) break; vec3 d=uLampPos[i]-vWorld; float dist=length(d); float att=1.0/(1.0+0.12*dist+0.045*dist*dist); float lam=max(dot(N,normalize(d)),0.0); col += uLampColor[i]*att*(0.15+lam*0.85)*0.8; }
    float fog=clamp((length(uEye-vWorld)-uFogNear)/(uFogFar-uFogNear),0.0,1.0);
    vec3 fogCol=vec3(0.14,0.19,0.27);
    col=mix(col,fogCol,fog*0.88);
    outColor=vec4(col,1.0);
  }`;
  const pointVertex = `#version 300 es
  precision highp float; layout(location=0) in vec3 aPosition; uniform mat4 uProjection; uniform mat4 uView; uniform float uPointSize; out float vDepth;
  void main(){ vec4 p=uView*vec4(aPosition,1.0); gl_Position=uProjection*p; gl_PointSize=max(1.0,uPointSize*(12.0/max(1.0,-p.z))); vDepth=-p.z; }`;
  const pointFragment = `#version 300 es
  precision highp float; uniform vec3 uPointColor; uniform float uSoft; out vec4 outColor;
  void main(){ vec2 p=gl_PointCoord-0.5; float r=length(p); float a=1.0-smoothstep(0.22,0.5,r); if(a<0.01) discard; outColor=vec4(uPointColor,a*uSoft); }`;

  function compile(type, source) { const s=gl.createShader(type); gl.shaderSource(s,source); gl.compileShader(s); if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; }
  function program(vs,fs){ const p=gl.createProgram(); gl.attachShader(p,compile(gl.VERTEX_SHADER,vs)); gl.attachShader(p,compile(gl.FRAGMENT_SHADER,fs)); gl.linkProgram(p); if(!gl.getProgramParameter(p,gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p)); return p; }
  let meshProgram, pointProgram;
  try { meshProgram=program(vertexSource,fragmentSource); pointProgram=program(pointVertex,pointFragment); }
  catch(e){ statusText.textContent='SHADER INITIALIZATION FAILED'; console.error(e); return; }
  const U={}; ['uProjection','uView','uEye','uFogNear','uFogFar','uLampPos[0]','uLampColor[0]','uLampCount'].forEach(k=>U[k]=gl.getUniformLocation(meshProgram,k));
  const PU={}; ['uProjection','uView','uPointSize','uPointColor','uSoft'].forEach(k=>PU[k]=gl.getUniformLocation(pointProgram,k));
  const ID=()=>mat4Identity();
  function mat4Identity(){return new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);}
  function mat4FromArray(data,offset=0){return new Float32Array(data.subarray(offset,offset+16));}
  function mat4Mul(a,b){const o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o;}
  function perspective(fovy,aspect,near,far){const f=1/Math.tan(fovy/2),nf=1/(near-far),o=new Float32Array(16);o[0]=f/aspect;o[5]=f;o[10]=(far+near)*nf;o[11]=-1;o[14]=2*far*near*nf;return o;}
  function lookAt(eye,center,up){const z=norm(sub(eye,center)),x=norm(cross(up,z)),y=cross(z,x),o=ID();o[0]=x[0];o[1]=y[0];o[2]=z[0];o[4]=x[1];o[5]=y[1];o[6]=z[1];o[8]=x[2];o[9]=y[2];o[10]=z[2];o[12]=-dot(x,eye);o[13]=-dot(y,eye);o[14]=-dot(z,eye);return o;}
  function sub(a,b){return [a[0]-b[0],a[1]-b[1],a[2]-b[2]];} function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];} function dot(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];} function norm(a){const l=Math.hypot(...a)||1;return [a[0]/l,a[1]/l,a[2]/l];}
  function modelMatrix(pos=[0,0,0],rot=[0,0,0],scale=[1,1,1]){const [x,y,z]=rot,cx=Math.cos(x),sx=Math.sin(x),cy=Math.cos(y),sy=Math.sin(y),cz=Math.cos(z),sz=Math.sin(z);const rx=ID(),ry=ID(),rz=ID(),sc=ID();rx[5]=cx;rx[6]=sx;rx[9]=-sx;rx[10]=cx;ry[0]=cy;ry[2]=-sy;ry[8]=sy;ry[10]=cy;rz[0]=cz;rz[1]=sz;rz[4]=-sz;rz[5]=cz;sc[0]=scale[0];sc[5]=scale[1];sc[10]=scale[2];let m=mat4Mul(mat4Mul(mat4Mul(rz,ry),rx),sc);m[12]=pos[0];m[13]=pos[1];m[14]=pos[2];return m;}

  function makeMesh(vertices,indices,hasVertexColors=false){
    const vao=gl.createVertexArray();gl.bindVertexArray(vao);
    const vbo=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vbo);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vertices),gl.STATIC_DRAW);
    const stride=hasVertexColors?36:24;
    gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,stride,0);
    gl.enableVertexAttribArray(1);gl.vertexAttribPointer(1,3,gl.FLOAT,false,stride,12);
    if(hasVertexColors){gl.enableVertexAttribArray(2);gl.vertexAttribPointer(2,3,gl.FLOAT,false,stride,24);}else{gl.disableVertexAttribArray(2);gl.vertexAttrib3f(2,1,1,1);}
    const ibo=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ibo);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint32Array(indices),gl.STATIC_DRAW);
    gl.bindVertexArray(null);return {vao,count:indices.length,hasVertexColors};
  }
  function makeColorMesh(vertices,indices){return makeMesh(vertices,indices,true);}
  function addFace(out,a,b,c){const n=norm(cross(sub(c,a),sub(b,a)));for(const p of [a,b,c])out.push(p[0],p[1],p[2],n[0],n[1],n[2]);}
  function meshFromFaces(faces){const verts=[],idx=[];for(const f of faces){const base=verts.length/6;addFace(verts,f[0],f[1],f[2]);idx.push(base,base+1,base+2);}return makeMesh(verts,idx);}
  function boxMesh(){const f=[],p=[[-.5,-.5,-.5],[.5,-.5,-.5],[.5,.5,-.5],[-.5,.5,-.5],[-.5,-.5,.5],[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5]];const q=[[0,1,2,3],[5,4,7,6],[4,0,3,7],[1,5,6,2],[3,2,6,7],[4,5,1,0]];for(const a of q){f.push([p[a[0]],p[a[1]],p[a[2]]],[p[a[0]],p[a[2]],p[a[3]]]);}return meshFromFaces(f);}
  function coneMesh(rad=1,height=1,segments=12){const f=[];for(let i=0;i<segments;i++){const a=i/segments*Math.PI*2,b=(i+1)/segments*Math.PI*2,p0=[Math.cos(a)*rad,0,Math.sin(a)*rad],p1=[Math.cos(b)*rad,0,Math.sin(b)*rad],tip=[0,height,0];f.push([p0,p1,tip],[p1,p0,[0,0,0]]);}return meshFromFaces(f);}
  function cylinderMesh(rad=.5,height=1,segments=12){const f=[];for(let i=0;i<segments;i++){const a=i/segments*Math.PI*2,b=(i+1)/segments*Math.PI*2,p0=[Math.cos(a)*rad,-height/2,Math.sin(a)*rad],p1=[Math.cos(b)*rad,-height/2,Math.sin(b)*rad],p2=[Math.cos(b)*rad,height/2,Math.sin(b)*rad],p3=[Math.cos(a)*rad,height/2,Math.sin(a)*rad];f.push([p0,p1,p2],[p0,p2,p3],[p3,p2,[0,height/2,0]],[p0,[0,-height/2,0],p1]);}return meshFromFaces(f);}
  function planeGrid(size,segments,fn,colorFn){
    const verts=[],idx=[],eps=.18;
    for(let z=0;z<=segments;z++)for(let x=0;x<=segments;x++){
      const px=(x/segments-.5)*size,pz=(z/segments-.5)*size,y=fn(px,pz);
      const dx=(fn(px+eps,pz)-fn(px-eps,pz))/(2*eps),dz=(fn(px,pz+eps)-fn(px,pz-eps))/(2*eps);
      const normal=norm([-dx,1,-dz]);
      const color=colorFn?colorFn(px,pz,y):[1,1,1];
      verts.push(px,y,pz,normal[0],normal[1],normal[2],color[0],color[1],color[2]);
    }
    for(let z=0;z<segments;z++)for(let x=0;x<segments;x++){const a=z*(segments+1)+x,b=a+1,c=a+segments+1,d=c+1;idx.push(a,c,b,b,c,d);}
    return makeColorMesh(verts,idx);
  }
  // M2 shared high-detail winter vegetation. The geometry is authored once per
  // species and instanced throughout the forest, keeping draw calls low.
  const clamp01=v=>Math.max(0,Math.min(1,v));
  const mix3=(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];
  const vAdd=(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]];
  const vSub=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]];
  const vMul=(a,k)=>[a[0]*k,a[1]*k,a[2]*k];
  function pushColoredVertex(out,p,n,c){out.push(p[0],p[1],p[2],n[0],n[1],n[2],c[0],c[1],c[2]);}
  function addColoredTri(out,idx,a,b,c,ca,cb,cc,na=null,nb=null,nc=null){
    const face=norm(cross(sub(c,a),sub(b,a)));const base=out.length/9;
    pushColoredVertex(out,a,na||face,ca);pushColoredVertex(out,b,nb||face,cb);pushColoredVertex(out,c,nc||face,cc);
    idx.push(base,base+1,base+2);
  }
  function addTube(out,idx,points,radii,color,sides=7,seed=0){
    const rings=[];
    for(let j=0;j<points.length;j++){
      const tangent=norm(vSub(points[Math.min(points.length-1,j+1)],points[Math.max(0,j-1)]));
      let ref=Math.abs(tangent[1])<.86?[0,1,0]:[0,0,1];
      const u=norm(cross(tangent,ref)),v=norm(cross(tangent,u)),ring=[];
      for(let k=0;k<sides;k++){
        const a=k/sides*Math.PI*2,rad=vAdd(vMul(u,Math.cos(a)),vMul(v,Math.sin(a)));
        const p=vAdd(points[j],vMul(rad,radii[j]));
        const variation=1+Math.sin((k+1)*12.9898+(j+1)*78.233+seed)*.045;
        const c=color.map((q,n)=>q*variation*(n===0?1:1));
        const base=out.length/9;pushColoredVertex(out,p,rad,c);ring.push(base);
      }
      rings.push(ring);
    }
    for(let j=0;j<rings.length-1;j++)for(let k=0;k<sides;k++){
      const a=rings[j][k],b=rings[j][(k+1)%sides],c=rings[j+1][k],d=rings[j+1][(k+1)%sides];
      idx.push(a,c,b,b,c,d);
    }
  }
  function addNeedle(out,idx,base,axis,length,width,color,seed){
    const d=norm(axis);let ref=Math.abs(d[1])<.9?[0,1,0]:[1,0,0];
    const side=norm(cross(d,ref)),up=norm(cross(side,d));
    const tip=vAdd(base,vMul(d,length));
    const left=vAdd(vAdd(base,vMul(up,width)),vMul(side,width*.20));
    const right=vAdd(vSub(base,vMul(up,width)),vMul(side,-width*.20));
    const back=vAdd(base,vMul(side,-width*.45));
    const bright=mix3(color,[.18,.27,.22],.16+((seed%7)/7)*.13);
    addColoredTri(out,idx,base,left,tip,color,bright,color);
    addColoredTri(out,idx,left,right,tip,bright,color,bright);
    addColoredTri(out,idx,right,back,tip,color,color,bright);
    addColoredTri(out,idx,back,base,tip,bright,color,color);
  }
  function addNeedleSpray(out,idx,center,branchDir,scale,seed){
    const d=norm(branchDir);let side=norm(cross(d,[0,1,0]));if(Math.hypot(...side)<.01)side=[1,0,0];
    const up=norm(cross(side,d));
    const greens=[[.045,.135,.108],[.055,.16,.126],[.067,.185,.143],[.082,.205,.157],[.095,.22,.17]];
    // Individual modeled needle sprays break up the silhouette of the fuller bough masses.
    for(let k=0;k<7;k++){
      const a=(k/7)*Math.PI*2+seed*.37;
      const radial=vAdd(vMul(side,Math.cos(a)),vMul(up,Math.sin(a)));
      const axis=norm(vAdd(vMul(d,.68),vAdd(vMul(radial,.58),[0,.17,0])));
      const root=vAdd(center,vMul(radial,.045*scale));
      addNeedle(out,idx,root,axis,(.34+(k%4)*.073)*scale,.052*scale,greens[(k+seed)%greens.length],seed+k);
    }
  }
  function addFoliageBough(out,idx,start,end,scale,seed){
    const d=norm(vSub(end,start));let side=norm(cross(d,[0,1,0]));if(Math.hypot(...side)<.01)side=[1,0,0];
    const up=norm(cross(side,d)),stations=4,segments=8,rings=[];
    const greens=[[.052,.142,.112],[.064,.165,.13],[.078,.19,.148],[.092,.215,.164],[.105,.23,.174]];
    for(let j=0;j<=stations;j++){
      const t=j/stations,profile=Math.pow(Math.max(.02,Math.sin(Math.PI*t)),.72);
      const center=vAdd(start,vMul(vSub(end,start),t)),ring=[];
      for(let k=0;k<segments;k++){
        const a=k/segments*Math.PI*2;
        const irregular=1+.11*Math.sin(a*3+seed)+.045*Math.cos(t*9+seed);
        const width=.275*scale*profile*irregular,height=.185*scale*profile*irregular;
        const p=vAdd(center,vAdd(vMul(side,Math.cos(a)*width),vMul(up,Math.sin(a)*height)));
        const n=norm(vAdd(vMul(side,Math.cos(a)),vMul(up,Math.sin(a))));
        const tint=1+((j*3+k+seed)%5)*.025;const base=greens[(k+seed)%greens.length];
        const color=[base[0]*tint,base[1]*tint,base[2]*tint];
        const vi=out.length/9;pushColoredVertex(out,p,n,color);ring.push(vi);
      }
      rings.push(ring);
    }
    for(let j=0;j<stations;j++)for(let k=0;k<segments;k++){
      const a=rings[j][k],b=rings[j][(k+1)%segments],c=rings[j+1][k],d0=rings[j+1][(k+1)%segments];idx.push(a,c,b,b,c,d0);
    }
  }
  function addSnowRibbon(out,idx,start,end,scale,seed){
    // Broader, slightly deeper snow pillows sit on the upper side of each bough.
    // The open underside and tapered ends keep the snow visually attached to
    // the branch instead of reading as a closed white tube.
    const d=norm(vSub(end,start));let side=norm(cross(d,[0,1,0]));
    if(Math.hypot(...side)<.01)side=[1,0,0];
    let up=norm(cross(side,d));if(up[1]<0){up=vMul(up,-1);side=vMul(side,-1);}
    const stations=8,across=7,rings=[];
    const widthFactor=.305+(.035*Math.sin(seed*1.31));
    const depthFactor=.125+(.018*Math.cos(seed*1.73));
    for(let j=0;j<=stations;j++){
      const t=j/stations,profile=.12+Math.pow(Math.max(.001,Math.sin(Math.PI*t)),.38)*.88;
      const drift=.018*Math.sin(seed*2.1+t*7.7)+.009*Math.cos(seed+t*11.4);
      const center=vAdd(vAdd(start,vMul(vSub(end,start),t)),vMul(up,(.043*scale)+drift*scale));
      const ring=[];
      for(let k=0;k<=across;k++){
        const u=k/across*2-1;
        const waviness=1+.075*Math.sin(seed*1.7+t*8.2+k*2.4)+.035*Math.cos(seed+k*3.3);
        const width=widthFactor*scale*profile*waviness;
        const crown=Math.sqrt(Math.max(0,1-u*u));
        const height=depthFactor*scale*profile*crown;
        const p=vAdd(center,vAdd(vMul(side,u*width),vMul(up,.024*scale+height)));
        const n=norm(vAdd(vMul(up,.92+.32*crown),vMul(side,-u*.20)));
        const shade=.94+((j*3+k+seed)%7)*.009;
        const color=[.85*shade,.91*shade,.985*shade];
        const vi=out.length/9;pushColoredVertex(out,p,n,color);ring.push(vi);
      }
      rings.push(ring);
    }
    for(let j=0;j<stations;j++)for(let k=0;k<across;k++){
      const a=rings[j][k],b=rings[j][k+1],c=rings[j+1][k],d0=rings[j+1][k+1];
      idx.push(a,c,b,b,c,d0);
    }
  }

  function buildFirSpecies(params,seed){
    const verts=[],idx=[],height=params.height,radius=params.radius,levels=params.levels,baseBranches=params.branches;
    const style=params.style||'spruce';
    const trunkColor=[.19,.105,.067];
    const localRand=(n)=>{const x=Math.sin(n*127.1+seed*311.7)*43758.5453;return x-Math.floor(x);};
    const trunkPoints=[];
    for(let j=0;j<=12;j++){
      const t=j/12;
      const lean=Math.sin(t*2.1+seed)*.16*t+Math.sin(t*5.3+seed*.7)*.038*t;
      const sweep=Math.sin(t*3.7+seed*1.7)*.055*t;
      trunkPoints.push([lean,height*t,Math.cos(t*1.7+seed)*.105*t+sweep]);
    }
    addTube(verts,idx,trunkPoints,[.34,.315,.285,.255,.22,.19,.16,.13,.10,.075,.05,.025,.004],trunkColor,12,seed);
    // The leader is deliberately a little irregular rather than a perfectly
    // straight cone axis, especially on the cedar and open-fir variants.
    const leaderLean=style==='cedar'?.10:style==='openFir'?.16:.035;
    addTube(verts,idx,[[0,height*.70,0],[leaderLean*.35,height*.82,.012],[leaderLean,height*.93,.025],[leaderLean*.78,height,.015]],[.092,.067,.038,.005],[.22,.13,.085],8,seed+3);

    let whorlPhase=seed*.417;
    for(let level=0;level<levels;level++){
      const t=level/Math.max(1,levels-1);
      const yBase=1.02+t*(height-1.55);
      const yJitter=(localRand(level*71+seed*17)-.5)*(.13+.12*t);
      const y=yBase+yJitter;
      let taper;
      if(style==='spruce') taper=Math.pow(1-t,.83);
      else if(style==='cedar') taper=Math.pow(1-t,.67);
      else taper=Math.pow(1-t,.74)*(1+.08*Math.sin(level*1.9+seed));
      const spread=radius*(.94-.72*t)*taper*(params.spread||1);
      const countSwing=Math.floor(localRand(level*103+seed*31)*3)-1;
      const count=Math.max(4,baseBranches+countSwing+(level%4===1?1:0));
      const basePhase=whorlPhase;
      whorlPhase += 2.399963+(.24+localRand(level*113+seed*43)*.46)*(level%2?1:-1);
      for(let b=0;b<count;b++){
        const branchSeed=level*197+b*53+seed*29;
        // Missing and clustered branches, a shifting whorl phase, and substantial
        // per-bough length variation break the repeated radial pinwheel silhouette.
        if(localRand(branchSeed+2)<(style==='cedar'?.095:.055))continue;
        const angularJitter=(localRand(branchSeed)-.5)*(style==='openFir'?.76:.58);
        const angle=basePhase+(b/count)*Math.PI*2+angularJitter;
        const dx=Math.cos(angle),dz=Math.sin(angle);
        const branchFactor=.69+localRand(branchSeed+4)*.58;
        const asymmetry=1+.13*Math.sin(angle*2.0+seed)*Math.sin(t*4.3+seed*.8);
        const branchSpread=spread*branchFactor*asymmetry;
        const sway=(localRand(branchSeed+8)-.5)*.31;
        const droopBase=style==='spruce'?.19:style==='cedar'?.33:.25;
        const droop=droopBase+localRand(branchSeed+12)*.30;
        const upSweep=(style==='spruce'?.17:style==='cedar'?.055:.12)*(1-t);
        const p0=[dx*.055,y,dz*.055];
        const p1=[dx*branchSpread*.30,y+.12+sway*.45+upSweep*.35,dz*branchSpread*.30];
        const p2=[dx*branchSpread*.66,y+.025+sway+upSweep*.38,dz*branchSpread*.66];
        const p3=[dx*branchSpread,y-droop+upSweep,dz*branchSpread];
        addTube(verts,idx,[p0,p1,p2,p3],[.102*(1-t*.52),.076*(1-t*.50),.045*(1-t*.42),.010],[.20,.115,.072],6,branchSeed);
        const dir=norm(vSub(p3,p0));
        const sprayPositions=style==='cedar'?[.16,.34,.53,.72,.91]:[.18,.40,.62,.82,.97];
        for(let q=0;q<sprayPositions.length;q++){
          const along=sprayPositions[q];
          const center=vAdd(p0,vMul(vSub(p3,p0),along));
          addNeedleSpray(verts,idx,center,dir,(.93+localRand(branchSeed+q*13)*.24)*(1-t*.20),branchSeed+q*31);
        }
        const lateral=norm([-dz,0,dx]);
        const forkCount=style==='openFir'?3:2;
        for(let fork=0;fork<forkCount;fork++){
          const sign=(fork%2===0)?1:-1;
          const at=forkCount===3?[.34,.59,.82][fork]:(fork===0?.36:.72);
          const root=vAdd(p0,vMul(vSub(p3,p0),at+(localRand(branchSeed+fork*5)-.5)*.075));
          const forkLen=branchSpread*(.14+localRand(branchSeed+fork*9)*.16);
          const radialMix=style==='cedar'?.42:.54;
          const sideDir=vAdd(vMul([dx,0,dz],radialMix),vMul(lateral,sign*(.62+localRand(branchSeed+fork*7)*.16)));
          const forkLift=style==='spruce'?.18:.115;
          const forkMid=vAdd(root,vAdd(vMul(sideDir,forkLen*.47),[0,forkLift*.55,0]));
          const forkTip=vAdd(root,vAdd(vMul(sideDir,forkLen),[0,forkLift+localRand(branchSeed+fork*11)*.07,0]));
          addTube(verts,idx,[root,forkMid,forkTip],[.036*(1-t*.4),.016,.0025],[.19,.112,.071],5,branchSeed+fork*23);
          addNeedleSpray(verts,idx,forkMid,sideDir,.53*(1-t*.12),branchSeed+fork*29);
          addNeedleSpray(verts,idx,forkTip,sideDir,.46*(1-t*.12),branchSeed+fork*37);
        }
        // Unequal overlapping foliage sections leave natural scallops instead of
        // one continuous perfect cone or cylinder around each branch.
        const foliageA=vAdd(p0,vMul(vSub(p3,p0),.07));
        const foliageB=vAdd(p0,vMul(vSub(p3,p0),.54));
        const foliageC=vAdd(p0,vMul(vSub(p3,p0),.40));
        const foliageD=vAdd(p0,vMul(vSub(p3,p0),.84));
        const fullness=style==='spruce'?1.0:style==='cedar'?.84:.91;
        addFoliageBough(verts,idx,foliageA,foliageB,fullness*(.94+localRand(branchSeed+51)*.16)*(1-t*.20),branchSeed+61);
        addFoliageBough(verts,idx,foliageC,foliageD,fullness*(.77+localRand(branchSeed+57)*.21)*(1-t*.16),branchSeed+67);
        if(localRand(branchSeed+63)>.18)addFoliageBough(verts,idx,foliageD,p3,fullness*(.56+localRand(branchSeed+69)*.18)*(1-t*.13),branchSeed+73);
        // Broader snow pillows remain visible from below and at normal walking height.
        if(level<levels-1&&localRand(branchSeed+79)>(style==='cedar'?.10:.04)){
          const snowStart=vAdd(p0,vMul(vSub(p3,p0),.22));
          const snowEnd=vAdd(p0,vMul(vSub(p3,p0),.99));
          addSnowRibbon(verts,idx,snowStart,snowEnd,(.95+localRand(branchSeed+83)*.22)*(1-t*.16),branchSeed+89);
        }
      }
    }
    // Sparse exposed leaders and twig tips interrupt the crown outline. Their
    // positions follow a low-discrepancy spiral but receive independent offsets.
    const twigCount=style==='openFir'?36:30;
    for(let j=0;j<twigCount;j++){
      const t=.22+localRand(j*37+seed*101)*.72,a=j*2.399963+seed*.73+(localRand(j*53+seed)*.35);
      const radial=radius*(1-t)*(.34+localRand(j*61+seed*3)*.34);
      const start=[Math.cos(a)*radial,height*t,Math.sin(a)*radial];
      const len=.28+localRand(j*71+seed*7)*.48;
      const end=[start[0]+Math.cos(a)*len,start[1]+.08+localRand(j*83+seed)*.17,start[2]+Math.sin(a)*len];
      const mid=vAdd(start,vMul(vSub(end,start),.58));
      addTube(verts,idx,[start,mid,end],[.026,.013,.0025],[.17,.105,.07],5,seed+j*3);
      if(j%2===0)addNeedleSpray(verts,idx,end,vSub(end,start),.36+localRand(j*97+seed)*.15,seed+j*11);
    }
    return makeColorMesh(verts,idx);
  }

  function addCherryFlower(out,idx,center,normal,size,seed){
    const axis=norm(normal);let ref=Math.abs(axis[1])<.88?[0,1,0]:[1,0,0];
    const u=norm(cross(ref,axis)),v=norm(cross(axis,u));
    const palette=[[.91,.48,.60],[.98,.68,.76],[1.0,.78,.83],[.84,.36,.51]];
    for(let p=0;p<5;p++){
      const a=p*Math.PI*2/5+seed*.071,radial=vAdd(vMul(u,Math.cos(a)),vMul(v,Math.sin(a)));
      const lateral=norm(cross(axis,radial));
      const base=vAdd(center,vMul(radial,.012*size));
      const middle=vAdd(vAdd(center,vMul(radial,.43*size)),vMul(axis,.040*size));
      const tip=vAdd(vAdd(center,vMul(radial,.86*size)),vMul(axis,.014*size));
      const left=vAdd(middle,vMul(lateral,.49*size)),right=vAdd(middle,vMul(lateral,-.49*size));
      const cup=vAdd(middle,vMul(axis,.042*size));
      const c0=palette[(p+seed)%palette.length],c1=palette[(p+seed+1)%palette.length];
      addColoredTri(out,idx,base,left,cup,c0,c1,c1,axis,axis,axis);
      addColoredTri(out,idx,left,tip,cup,c1,c0,c1,axis,axis,axis);
      addColoredTri(out,idx,tip,right,cup,c0,c1,c1,axis,axis,axis);
      addColoredTri(out,idx,right,base,cup,c1,c0,c1,axis,axis,axis);
    }
    // Small golden-pink center, faceted rather than a flat dot.
    const r=size*.105,c=vAdd(center,vMul(axis,size*.13)),gold=[.96,.69,.38],pink=[.72,.30,.42];
    const top=vAdd(c,vMul(axis,r)),bottom=vSub(c,vMul(axis,r));
    const basis=[u,v];
    const ring=[];for(let k=0;k<6;k++){const a=k*Math.PI/3,dir=vAdd(vMul(u,Math.cos(a)),vMul(v,Math.sin(a)));ring.push(vAdd(c,vMul(dir,r)));}
    for(let k=0;k<6;k++){
      addColoredTri(out,idx,top,ring[k],ring[(k+1)%6],gold,gold,pink,axis,axis,axis);
      addColoredTri(out,idx,bottom,ring[(k+1)%6],ring[k],pink,gold,gold,vMul(axis,-1),vMul(axis,-1),vMul(axis,-1));
    }
  }
  function buildSakuraFlowerMesh(){
    // A compact five-petal blossom. Thousands of source placement transforms
    // instance this shared mesh instead of duplicating petal geometry.
    const verts=[],idx=[];
    addCherryFlower(verts,idx,[0,0,0],[0,0,1],.030,23);
    return makeColorMesh(verts,idx);
  }
  function buildSnowRockMesh(seed=1,variant=0){
    const verts=[],idx=[],rings=10,segs=20,ringIds=[];
    for(let r=0;r<=rings;r++){
      const phi=.035+(r/rings)*(Math.PI-.07),ring=[];
      for(let k=0;k<segs;k++){
        const a=k/segs*Math.PI*2;
        const n1=Math.sin(a*3+seed)*.15+Math.cos(a*5+seed*.7)*.065;
        const n2=Math.sin(phi*4+seed*.4+a*2.2)*.065;
        const wobble=1+n1+n2;
        const nx=Math.sin(phi)*Math.cos(a),ny=Math.cos(phi),nz=Math.sin(phi)*Math.sin(a);
        const baseX=variant?.56:.50,baseZ=variant?.39:.46;
        const flat=ny<-.55?.76:1.0;
        const p=[nx*baseX*wobble,ny*(variant?.31:.34)*wobble*flat-.045,nz*baseZ*wobble];
        const n=norm([nx*(.75+n1),ny*(1.05+n2),nz*(.75+n1)]);
        const rockNoise=.5+.5*Math.sin(a*7+phi*8+seed)*Math.cos(a*3-phi*5+seed*.3);
        const stone=mix3([.115,.145,.19],[.25,.27,.30],rockNoise);
        const snowEdge=.29+.055*Math.sin(a*3+seed)+.04*Math.cos(a*5+phi*4);
        const snow=clamp01((ny-snowEdge)*3.5);
        let c=mix3(stone,[.82,.89,.96],snow);
        // A few darker mineral facets remain visible through the snow line.
        const fleck=clamp01((.28-rockNoise)*.35)*(1-snow);
        c=mix3(c,[.075,.105,.14],fleck);
        const vi=verts.length/9;pushColoredVertex(verts,p,n,c);ring.push(vi);
      }
      ringIds.push(ring);
    }
    for(let r=0;r<rings;r++)for(let k=0;k<segs;k++){
      const a=ringIds[r][k],b=ringIds[r][(k+1)%segs],c=ringIds[r+1][k],d=ringIds[r+1][(k+1)%segs];idx.push(a,c,b,b,c,d);
    }
    return makeColorMesh(verts,idx);
  }

  const firSpecies=[
    buildFirSpecies({height:7.9,radius:2.72,levels:9,branches:7,spread:1,style:'spruce'},3),
    buildFirSpecies({height:9.2,radius:2.58,levels:10,branches:6,spread:.96,style:'cedar'},11),
    buildFirSpecies({height:5.8,radius:2.05,levels:7,branches:5,spread:1.10,style:'openFir'},19)
  ];
  const snowRock=buildSnowRockMesh(23,0), snowRockAlt=buildSnowRockMesh(37,1);
  // Reduced from the detailed cherry-tree source asset. The original multi-million
  // triangle tree and 29k blossom nodes are simplified and embedded locally so
  // the app continues to work from index.html without a network or GLTF loader.
  const sakuraData=window.WinterWorldSakuraData;
  if(!sakuraData) throw new Error('Sakura mesh data did not load. Keep src/sakura_mesh_data.js beside main.js.');
  function decodeTypedBase64(encoded,Type){
    const raw=atob(encoded),bytes=new Uint8Array(raw.length);
    for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
    if(bytes.byteLength%Type.BYTES_PER_ELEMENT!==0)throw new Error('Invalid embedded sakura mesh data.');
    return new Type(bytes.buffer);
  }
  const sakuraAsset=(()=>{
    const treeVertices=decodeTypedBase64(sakuraData.vertices,Float32Array);
    const treeIndices=decodeTypedBase64(sakuraData.indices,Uint32Array);
    const snowVertices=decodeTypedBase64(sakuraData.snowVertices,Float32Array);
    const snowIndices=decodeTypedBase64(sakuraData.snowIndices,Uint32Array);
    const flowerMatrices=decodeTypedBase64(sakuraData.flowerMatrices,Float32Array);
    const treeMesh=makeColorMesh(treeVertices,treeIndices);
    const snowMesh=makeColorMesh(snowVertices,snowIndices);
    // Release the large Base64 strings and temporary decoded arrays after WebGL
    // owns the buffers; keep only the compact authored blossom transforms.
    sakuraData.vertices='';sakuraData.indices='';sakuraData.snowVertices='';sakuraData.snowIndices='';sakuraData.flowerMatrices='';
    window.WinterWorldSakuraData=null;
    return {treeMesh,snowMesh,flowerMatrices};
  })();
  const sakuraTreeMesh=sakuraAsset.treeMesh;
  const sakuraSnowMesh=sakuraAsset.snowMesh;
  const sakuraFlowerMatrices=sakuraAsset.flowerMatrices;
  const sakuraFlowerMesh=buildSakuraFlowerMesh();
  const box=boxMesh(), pineCone=coneMesh(1,1,10), trunk=cylinderMesh(.18,1,8), cyl=cylinderMesh(.5,1,12);
  const objects=[];
  const colliders=[];
  function add(mesh,pos,scale,color,opts={}){objects.push({mesh,model:modelMatrix(pos,opts.rot||[0,0,0],scale),color,emissive:opts.emissive||0});}
  function addCircleCollider(x,z,radius,label){colliders.push({kind:'circle',x,z,radius,label});}
  function addBoxCollider(minX,maxX,minZ,maxZ,label){colliders.push({kind:'box',minX,maxX,minZ,maxZ,label});}
  const snowWhite=[.72,.82,.91], snowBlue=[.48,.61,.74], wood=[.22,.14,.105], darkWood=[.105,.09,.085], pineDark=[.035,.12,.105], pineLight=[.055,.19,.16], lampGold=[1,.56,.22], windowGlow=[1,.55,.19];
  // Shared height/center functions keep the compacted path and its snow edges aligned.
  const terrainHeight=(x,z)=>-.05+Math.sin(x*.11+z*.045)*.09+Math.cos(z*.13)*.06;
  const pathCenter=(t)=>Math.sin(t*5.3)*5+Math.sin(t*12)*.55;
  // Undulating snowfield.
  const terrain=planeGrid(160,110,terrainHeight,(x,z)=>{
    const drift=Math.sin(x*.19+z*.07)*Math.sin(z*.15-x*.11);
    const patch=Math.cos(x*.47+z*.31)*.012;
    return [.91+drift*.035+patch,.95+drift*.025+patch,1.0+drift*.012];
  });
  add(terrain,[0,0,0],[1,1,1],[.54,.66,.78]);
  // Curving compacted path made from a broad ribbon.
  function pathMesh(){
    const v=[],idx=[],steps=120;
    for(let i=0;i<=steps;i++){
      const t=i/steps,z=32-t*76,x=pathCenter(t);
      for(let side=0;side<2;side++){
        const xx=x+(side?1:-1)*2.0,yy=terrainHeight(xx,z)+.045;
        const grain=Math.sin(t*57+side*1.4)*.018+Math.sin(t*17)*.012;
        v.push(xx,yy,z,0,1,0,.89+grain,.93+grain*.7,.98);
      }
    }
    for(let i=0;i<steps;i++){const a=i*2;idx.push(a,a+2,a+1,a+1,a+2,a+3);}
    return makeColorMesh(v,idx);
  }
  add(pathMesh(),[0,0,0],[1,1,1],[.31,.41,.52]);
  // Continuous, softly raised snow shoulders. These replace the overlapping
  // circular mounds so the path edges read as deliberate banks, not scattered discs.
  function snowShoulderMesh(){
    const v=[],idx=[],steps=120,offsets=[2.0,2.45,3.15];
    for(const side of [-1,1]){
      const base=v.length/9;
      for(let i=0;i<=steps;i++){
        const t=i/steps,z=32-t*76,cx=pathCenter(t);
        const ridge=.105+Math.sin(t*28+side*1.7)*.012+Math.sin(t*11.5-side)*.008;
        const profiles=[.045,ridge,.018];
        for(let lane=0;lane<3;lane++){
          const x=cx+side*offsets[lane],y=terrainHeight(x,z)+profiles[lane];
          const grain=Math.sin(t*41+lane*2.3+side)*.018;
          v.push(x,y,z,0,1,0,.94+grain,.97+grain*.6,1.0);
        }
      }
      for(let i=0;i<steps;i++)for(let lane=0;lane<2;lane++){
        const a=base+i*3+lane,b=base+(i+1)*3+lane;
        idx.push(a,b,a+1,a+1,b,b+1);
      }
    }
    return makeColorMesh(v,idx);
  }
  add(snowShoulderMesh(),[0,0,0],[1,1,1],[.62,.72,.82]);
  // M2 forest composition: tall irregular conifers, narrow cedar forms, and
  // young understory trees. Each species is one shared mesh and is GPU-instanced.
  const rng=(n)=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
  // A small first sakura grove is reserved along the left side of the forest approach.
  const sakuraPositions=[[-11.6,5.0,1.00,0],[-19.8,-10.0,.94,1],[-13.7,-26.0,1.02,0],[-22.3,-42.5,.90,1]];
  function inSakuraGroveClearance(x,z){return sakuraPositions.some(([sx,sz])=>Math.hypot(x-sx,z-sz)<6.8);}
  function tree(x,z,sc=1,variant=0,addCollider=true){
    // Keep the denser M2 vegetation clear of the existing cabin and doorway.
    if(Math.abs(x-5)<7.2&&Math.abs(z+24)<8.0)return;
    if(inSakuraGroveClearance(x,z))return;
    if(addCollider)addCircleCollider(x,z,.31*sc,'tree trunk');
    const y=terrainHeight(x,z),species=variant%firSpecies.length,spin=rng(Math.round((x+75)*91+(z+70)*17))*Math.PI*2;
    const tint=.92+rng(Math.round(x*13+z*7))* .12;
    objects.push({mesh:firSpecies[species],model:modelMatrix([x,y,z],[0,spin,0],[sc,sc,sc]),color:[tint,tint*.99,tint*1.015],emissive:0});
  }
  let seed=1;
  for(let row=0;row<9;row++)for(let col=0;col<8;col++){
    const side=col<4?-1:1,z=34-row*9+rng(seed++)*4,x=side*(8+((col%4)*5)+rng(seed++)*3);
    tree(x,z,.82+rng(seed++)*.58,seed%3);
  }
  for(let i=0;i<23;i++){
    const z=28-rng(i+300)*83,x=(rng(i+800)<.5?-1:1)*(11+rng(i+500)*23);
    tree(x,z,.75+rng(i+900)*.68,i%3);
  }
  // Layered young growth fills gaps below the mature canopy without crowding the path.
  for(let i=0;i<34;i++){
    const side=rng(i+1200)<.5?-1:1,z=25-rng(i+1300)*76,x=side*(5.4+rng(i+1400)*8.2);
    if(Math.abs(x-pathCenter((32-z)/76))<5.0)continue;
    tree(x,z,.30+rng(i+1500)*.20,2,false);
  }
  // First Japanese cherry-blossom grove: broad natural crowns, dark branching,
  // individually modeled five-petal flowers, and snow resting on selected boughs.
  let sakuraBlossomInstanceCount=0;
  for(let i=0;i<sakuraPositions.length;i++){
    const [x,z,sc,variant]=sakuraPositions[i],y=terrainHeight(x,z),spin=rng(4100+i*17)*Math.PI*2;
    const treeScale=[sc*(.94+rng(i+4210)*.12),sc*(.97+rng(i+4310)*.06),sc*(.93+rng(i+4410)*.14)];
    const treeModel=modelMatrix([x,y,z],[0,spin,0],treeScale);
    objects.push({mesh:sakuraTreeMesh,model:treeModel,color:[1,1,1],emissive:0});
    // Higher-resolution snow deposits are a separate instanced mesh so they
    // retain their small authored clumps and sit just above the branch surfaces.
    objects.push({mesh:sakuraSnowMesh,model:treeModel,color:[1,1,1],emissive:0});
    // Blossom transforms follow the source model's natural branch distribution.
    // One small shared five-petal mesh is instanced at each retained flower point.
    for(let f=0;f<sakuraFlowerMatrices.length/16;f++){
      const local=mat4FromArray(sakuraFlowerMatrices,f*16);
      const world=mat4Mul(treeModel,local);
      const tint=.96+rng(i*12000+f*3+4700)*.08;
      objects.push({mesh:sakuraFlowerMesh,model:world,color:[tint,Math.min(1,tint*1.015),Math.min(1,tint*1.01)],emissive:0});
      sakuraBlossomInstanceCount++;
    }
    addCircleCollider(x,z,.48*sc,'sakura trunk');
  }
  // Irregular snow-capped boulders add a readable mid-ground scale layer.
  for(let i=0;i<34;i++){
    const side=rng(i+2100)<.5?-1:1,z=23-rng(i+2200)*72,x=side*(5.2+rng(i+2300)*16);
    if(Math.abs(x-pathCenter((32-z)/76))<4.0)continue;
    if(Math.abs(x-5)<7.2&&Math.abs(z+24)<8.0)continue;
    if(inSakuraGroveClearance(x,z))continue;
    const sc=.42+rng(i+2400)*.85,y=terrainHeight(x,z)+sc*.17,rockMesh=(i%3===0?snowRockAlt:snowRock);
    add(rockMesh,[x,y,z],[sc*(.9+rng(i+2500)*.5),sc,sc*(.85+rng(i+2600)*.45)],[1,1,1],{rot:[0,rng(i+2700)*Math.PI*2,0]});
    if(sc>.85)addCircleCollider(x,z,sc*.42,'snow-covered boulder');
  }
  // Smaller half-buried stones tie the larger boulders into the surrounding snow.
  for(let i=0;i<26;i++){
    const side=rng(i+3600)<.5?-1:1,z=21-rng(i+3700)*69,x=side*(5.8+rng(i+3800)*17);
    if(Math.abs(x-pathCenter((32-z)/76))<4.25||inSakuraGroveClearance(x,z))continue;
    const sc=.16+rng(i+3900)*.22,y=terrainHeight(x,z)+sc*.13,mesh=i%3===0?snowRockAlt:snowRock;
    add(mesh,[x,y,z],[sc*(.9+rng(i+4000)*.45),sc*.7,sc*(.8+rng(i+4100)*.45)],[1,1,1],{rot:[0,rng(i+4200)*Math.PI*2,0]});
  }
  // A few fallen limbs partially buried in snow give the forest floor a natural history.
  for(let i=0;i<7;i++){
    const x=(i%2?1:-1)*(9.4+rng(i+2700)*2.8),z=18-i*10.5,y=terrainHeight(x,z)+.18,angle=rng(i+2800)*.8-.4;
    if(Math.abs(x-5)<7.2&&Math.abs(z+24)<8.0)continue;
    const length=2.3+rng(i+2900)*1.5;
    add(trunk,[x,y,z],[.23,length,.23],[.18,.115,.075],{rot:[0,0,Math.PI/2+angle]});
    add(box,[x,y+.13,z],[length,.10,.28],[.70,.79,.87],{rot:[0,angle,0]});
  }
  // A small first-pass timber bakery/cabin at the end of the approach.
  const bx=5,bz=-24,by=.05;
  add(box,[bx,by+2.1,bz],[9,4.2,7],[.25,.19,.15]);
  // The cabin interior is not built yet, so the complete footprint is solid for now.
  addBoxCollider(bx-4.5,bx+4.5,bz-3.5,bz+3.5,'cabin');
  // Entry steps are walkable surfaces, not a solid collision box. Their tread
  // heights are handled by walkSurfaceHeight() below; the cabin wall itself
  // remains solid until the interior/doorway milestone.
  // Gable-end infill panels belong on the LEFT and RIGHT end walls (constant X).
  // The roof ridge runs along X, so its triangular end-wall openings are in the
  // Y/Z cross-section. Keep each panel exactly on the outer face of the cabin
  // body; do not push it out to the corner-post faces or onto the long front/back
  // walls. The wall body reaches y = by + 4.2 and x = bx +/- 4.5.
  const gableFaces=[];
  const gableNearZ=bz-3.5, gableFarZ=bz+3.5;
  const baseY=by+4.2, peakY=by+6.24;
  for(const side of [-1,1]){
    const x=bx+side*4.5;
    const near=[x,baseY,gableNearZ];
    const far=[x,baseY,gableFarZ];
    const peak=[x,peakY,bz];
    // meshFromFaces calculates normals with cross(c-a, b-a).
    // Reverse the winding on the negative-X end so both faces point outward.
    gableFaces.push(side===1 ? [near,far,peak] : [near,peak,far]);
  }
  const gableMesh=meshFromFaces(gableFaces);
  add(gableMesh,[0,0,0],[1,1,1],[.25,.19,.15]);
  // Wood corner posts and horizontal siding.
  for(const x of [bx-4.45,bx+4.45])for(const z of [bz-3.45,bz+3.45])add(box,[x,by+2.1,z],[.25,4.3,.25],[.12,.09,.075]);
  for(let y=.65;y<4.1;y+=.48){add(box,[bx,by+y,bz-3.57],[8.8,.075,.13],[.34,.23,.16]);add(box,[bx,by+y,bz+3.57],[8.8,.075,.13],[.34,.23,.16]);}
  // Gabled roof: the ridge runs along the building's X axis, so each roof
  // plane rotates around X (not Z). The two half-roofs meet at the ridge.
  const roofPitch=.48, roofCenterY=by+5.22;
  for(const side of [-1,1]){
    const rotX=side*roofPitch, centerZ=bz+side*1.90;
    add(box,[bx,roofCenterY,centerZ],[10.1,.38,4.2],[.12,.15,.20],{rot:[rotX,0,0]});
    // A slightly wider, offset snow cap sits on top of the timber roof panel.
    add(box,[bx,roofCenterY+.13,centerZ+side*.06],[10.2,.16,4.28],[.63,.72,.81],{rot:[rotX,0,0]});
  }
  // Slim snowy ridge cap hides the seam where both roof planes meet.
  add(box,[bx,by+6.27,bz],[10.25,.16,.24],[.68,.77,.86]);
  // Front facade, door, windows and warm interiors.
  add(box,[bx,by+1.4,bz-3.72],[1.5,2.8,.18],[.095,.065,.055]);
  add(box,[bx-2.3,by+2.2,bz-3.76],[1.45,1.55,.12],[.12,.075,.055]);
  add(box,[bx-2.3,by+2.2,bz-3.84],[1.18,1.28,.045],[.96,.48,.18],{emissive:.9});
  add(box,[bx+2.5,by+2.2,bz-3.76],[1.45,1.55,.12],[.12,.075,.055]);
  add(box,[bx+2.5,by+2.2,bz-3.84],[1.18,1.28,.045],[.96,.48,.18],{emissive:.9});
  // Signboard mounted on the front wall below the eaves, not floating above the roof.
  add(box,[bx,by+3.72,bz-3.68],[2.25,.55,.12],[.25,.16,.10]);
  for(let i=0;i<5;i++)add(box,[bx-.66+i*.32,by+3.72,bz-3.76],[.08,.18,.025],[.97,.74,.45],{emissive:.2});
  // Chimney and smoke hint.
  add(box,[bx+3.35,by+6.05,bz+.9],[.9,2.1,.9],[.23,.20,.18]);
  // Steps and path to entrance.
  // Stair treads rise toward the doorway and physically meet the sloping
  // terrain. The top of the highest tread aligns with the door sill.
  for(let i=0;i<4;i++){
    const treadZ=bz-4.3-i*.65;
    const treadTop=terrainHeight(bx,treadZ)+(4-i)*.05;
    add(box,[bx,treadTop-.1,treadZ],[2.8,.2,1.05],[.47,.59,.68]);
  }
  // Warm lantern posts along the path.
  const lampPositions=[[-5,13],[7,4],[-7,-4],[12,-14],[0,-20],[10,-28]];
  const lampLights=[];
  for(const [x,z] of lampPositions){addCircleCollider(x,z,.13,'lantern post');const y=.15+Math.sin(x*.11+z*.045)*.09+Math.cos(z*.13)*.06;add(trunk,[x,y+1.5,z],[.16,3,.16],[.16,.12,.09]);add(box,[x,y+2.8,z],[.72,.72,.72],[.13,.13,.16]);add(box,[x,y+2.8,z],[.48,.48,.48],lampGold,{emissive:1.1});add(box,[x,y+3.2,z],[.88,.12,.88],[.10,.11,.15]);lampLights.push([x,y+2.7,z]);}
  // Distant ridgeline silhouettes stay simple LODs so the far skyline remains inexpensive.
  for(let i=0;i<12;i++){const x=(i-5.5)*18,z=-67-rng(i+75)*20,h=10+rng(i+43)*16;add(pineCone,[x,h*.08,z],[11,h,11],[.11,.18,.26]);}
  for(let i=0;i<28;i++){
    const x=-92+rng(i+3100)*184,z=-72-rng(i+3200)*17,h=6+rng(i+3300)*9;
    add(pineCone,[x,h*.48,z],[1.7+rng(i+3400)*1.2,h,1.7+rng(i+3500)*1.2],[.075,.13,.19]);
  }
  // Moon disc.
  add(cyl,[-42,36,-95],[7,.6,7],[.73,.82,.92],{rot:[Math.PI/2,0,0],emissive:.32});

  // Batch static scene instances by shared geometry. This avoids a separate draw
  // call for every tree component, an important baseline for the target GTX 1050 Ti.
  const batches = new Map();
  for (const o of objects) {
    let batch = batches.get(o.mesh);
    if (!batch) { batch = { mesh: o.mesh, instances: [] }; batches.set(o.mesh, batch); }
    batch.instances.push(o);
  }
  const sceneBatches = [];
  let sceneInstanceCount=0,sceneTriangleCount=0;
  for (const batch of batches.values()) {
    const data = new Float32Array(batch.instances.length * 20);
    let cursor = 0;
    for (const instance of batch.instances) {
      data.set(instance.model, cursor); cursor += 16;
      data.set(instance.color, cursor); cursor += 3;
      data[cursor++] = instance.emissive;
    }
    gl.bindVertexArray(batch.mesh.vao);
    const instanceBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, instanceBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    const stride = 20 * 4;
    for (let col = 0; col < 4; col++) {
      const loc = 3 + col;
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, 4, gl.FLOAT, false, stride, col * 16);
      gl.vertexAttribDivisor(loc, 1);
    }
    gl.enableVertexAttribArray(7); gl.vertexAttribPointer(7, 3, gl.FLOAT, false, stride, 64); gl.vertexAttribDivisor(7, 1);
    gl.enableVertexAttribArray(8); gl.vertexAttribPointer(8, 1, gl.FLOAT, false, stride, 76); gl.vertexAttribDivisor(8, 1);
    gl.bindVertexArray(null);
    sceneBatches.push({ mesh: batch.mesh, count: batch.instances.length });
    sceneInstanceCount+=batch.instances.length;
    sceneTriangleCount+=(batch.mesh.count/3)*batch.instances.length;
  }

  // A tiny observability system: lamps are the only point-light sources in this foundation pass.
  const lampColors=lampLights.map(()=>[1.0,.55,.25]);
  const stars=[];for(let i=0;i<420;i++){const a=rng(i+1000)*Math.PI*2, elev=.12+rng(i+2000)*.78, r=110;stars.push(Math.cos(a)*Math.cos(elev)*r,Math.sin(elev)*r+16,Math.sin(a)*Math.cos(elev)*r-25);}
  const starVao=gl.createVertexArray(),starVbo=gl.createBuffer();gl.bindVertexArray(starVao);gl.bindBuffer(gl.ARRAY_BUFFER,starVbo);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(stars),gl.STATIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,12,0);gl.bindVertexArray(null);
  const flakes=[];const flakeCount=1000;for(let i=0;i<flakeCount;i++)flakes.push({x:(rng(i+4000)-.5)*75,y:rng(i+5000)*34+1,z:(rng(i+6000)-.5)*80,v:.7+rng(i+7000)*1.5,s:.7+rng(i+8000)*1.2});
  const flakeVao=gl.createVertexArray(),flakeVbo=gl.createBuffer();gl.bindVertexArray(flakeVao);gl.bindBuffer(gl.ARRAY_BUFFER,flakeVbo);gl.bufferData(gl.ARRAY_BUFFER,flakeCount*3*4,gl.DYNAMIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,12,0);gl.bindVertexArray(null);

  const WALK_EYE_HEIGHT=1.72, PLAYER_RADIUS=.36;
  const camera={x:0,y:terrainHeight(0,18)+WALK_EYE_HEIGHT,z:18,yaw:Math.PI,pitch:0};
  let locked=false,entered=false,last=performance.now(),frameCount=0,fpsTimer=0,fps=0;
  let qualityMode='high',activeFlakeCount=1000,renderScale=1.6,lastCollisionEvents=0,renderCpuMs=0,debugTimer=0;
  // 0 means no app-imposed frame cap. requestAnimationFrame remains browser/display scheduled.
  let fpsLimit=0,nextFrameTime=0;
  const keys=new Set();
  const qualityProfiles={
    high:{scale:1.6,flakes:1000,label:'High',summary:'High · Render scale up to 1.6× · 1,000 snow particles'},
    balanced:{scale:1.3,flakes:650,label:'Balanced',summary:'Balanced · Render scale up to 1.3× · 650 snow particles'},
    performance:{scale:1.0,flakes:350,label:'Performance',summary:'Performance · Render scale up to 1.0× · 350 snow particles'}
  };
  function resize(){const dpr=Math.min(window.devicePixelRatio||1,renderScale);canvas.width=Math.max(1,Math.floor(innerWidth*dpr));canvas.height=Math.max(1,Math.floor(innerHeight*dpr));gl.viewport(0,0,canvas.width,canvas.height);}
  function applyQuality(mode,notify=true){const profile=qualityProfiles[mode]||qualityProfiles.high;qualityMode=mode;renderScale=profile.scale;activeFlakeCount=profile.flakes;resize();document.getElementById('qualityLabel').textContent=profile.label;document.getElementById('qualitySummary').textContent=profile.summary;document.querySelectorAll('[data-quality]').forEach(button=>button.classList.toggle('active',button.dataset.quality===mode));if(notify)showToast(profile.label+' graphics preset applied.');}
  const fpsProfiles={30:{label:'30 FPS',summary:'30 FPS cap · Reduced rendering workload'},60:{label:'60 FPS',summary:'60 FPS cap · Standard frame limit'},0:{label:'Unlocked',summary:'Unlocked · No additional app-imposed frame cap'}};
  function applyFrameLimit(value,notify=true){const limit=Number(value);fpsLimit=[0,30,60].includes(limit)?limit:0;nextFrameTime=0;const profile=fpsProfiles[fpsLimit];document.querySelectorAll('[data-fps-limit]').forEach(button=>button.classList.toggle('active',Number(button.dataset.fpsLimit)===fpsLimit));document.getElementById('fpsSummary').textContent=profile.summary;if(notify)showToast(profile.label+' frame mode selected.');}
  addEventListener('resize',resize);resize();
  function showToast(msg){toast.textContent=msg;toast.classList.add('show');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>toast.classList.remove('show'),3600);}
  function enter(){entered=true;intro.classList.add('hidden');crosshair.style.display='block';hudBottom.style.display='flex';reticleLabel.style.display='block';canvas.requestPointerLock?.();}
  document.getElementById('enterButton').addEventListener('click',enter);
  canvas.addEventListener('click',()=>{if(entered&&!locked&&!document.getElementById('settingsPanel').hidden) return;if(entered&&!locked)canvas.requestPointerLock?.();});
  document.addEventListener('pointerlockchange',()=>{locked=document.pointerLockElement===canvas;reticleLabel.style.display=entered&&!locked?'block':'none';});
  document.addEventListener('mousemove',e=>{if(!locked)return;camera.yaw-=e.movementX*.0022;camera.pitch-=e.movementY*.0019;camera.pitch=Math.max(-1.25,Math.min(1.25,camera.pitch));});
  const settingsPanel=document.getElementById('settingsPanel');
  function closeSettings(){settingsPanel.hidden=true;}
  document.getElementById('settingsButton').addEventListener('click',()=>{if(locked)document.exitPointerLock?.();settingsPanel.hidden=!settingsPanel.hidden;});
  document.getElementById('settingsClose').addEventListener('click',closeSettings);
  document.querySelectorAll('[data-quality]').forEach(button=>button.addEventListener('click',()=>applyQuality(button.dataset.quality)));
  document.querySelectorAll('[data-fps-limit]').forEach(button=>button.addEventListener('click',()=>applyFrameLimit(button.dataset.fpsLimit)));
  document.addEventListener('keydown',e=>{
    keys.add(e.code);
    if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();
    if(e.code==='KeyE'&&entered)showToast('M2 forest benchmark: flowering sakura grove, upgraded conifers, snow-covered branches, and layered winter ground detail.');
    if(e.code==='F3'){e.preventDefault();const panel=document.getElementById('debugPanel');panel.hidden=!panel.hidden;if(!panel.hidden&&locked)document.exitPointerLock?.();}
    if(e.code==='Escape')closeSettings();
  });
  addEventListener('keyup',e=>keys.delete(e.code));
  function stairSurfaceHeight(x,z){
    // Match the physical tread boxes. The treads overlap slightly in Z, so
    // choose the highest tread under the player at overlap boundaries. This
    // creates four small, climbable rises instead of one blocking collider.
    const halfWidth=1.4;
    if(x<bx-halfWidth-0.02||x>bx+halfWidth+0.02)return null;
    let top=null;
    for(let i=0;i<4;i++){
      const treadZ=bz-4.3-i*.65;
      if(Math.abs(z-treadZ)<=.525){
        const treadTop=terrainHeight(bx,treadZ)+(4-i)*.05;
        if(top===null||treadTop>top)top=treadTop;
      }
    }
    return top;
  }
  function walkSurfaceHeight(x,z){
    const base=terrainHeight(x,z);
    const stairTop=stairSurfaceHeight(x,z);
    if(stairTop!==null)return Math.max(base,stairTop);
    const t=(32-z)/76;
    if(t<0||t>1)return base;
    const center=pathCenter(t),offset=x-center,dist=Math.abs(offset);
    if(dist>3.15)return base;
    const side=offset<0?-1:1,ridge=.105+Math.sin(t*28+side*1.7)*.012+Math.sin(t*11.5-side)*.008;
    const edgeX=center+side*2.0,crestX=center+side*2.45,outerX=center+side*3.15;
    const edgeY=terrainHeight(edgeX,z)+.045,crestY=terrainHeight(crestX,z)+ridge,outerY=terrainHeight(outerX,z)+.018;
    if(dist<=2.0)return base+.045;
    if(dist<=2.45){const u=(dist-2.0)/.45;return edgeY+(crestY-edgeY)*u;}
    const u=(dist-2.45)/.70;return crestY+(outerY-crestY)*u;
  }
  function blockedAt(x,z){
    if(x<-54||x>54||z<-58||z>42)return true;
    for(const collider of colliders){
      if(collider.kind==='circle'){const dx=x-collider.x,dz=z-collider.z,r=PLAYER_RADIUS+collider.radius;if(dx*dx+dz*dz<r*r)return true;}
      else {const qx=Math.max(collider.minX,Math.min(x,collider.maxX)),qz=Math.max(collider.minZ,Math.min(z,collider.maxZ));const dx=x-qx,dz=z-qz;if(dx*dx+dz*dz<PLAYER_RADIUS*PLAYER_RADIUS)return true;}
    }
    return false;
  }
  function update(dt){
    const forward=(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0);
    const side=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0);
    const speed=(keys.has('ShiftLeft')||keys.has('ShiftRight')?7:3.6);
    const f=[Math.sin(camera.yaw),0,Math.cos(camera.yaw)],r=[-Math.cos(camera.yaw),0,Math.sin(camera.yaw)];
    let dx=(f[0]*forward+r[0]*side)*speed*dt,dz=(f[2]*forward+r[2]*side)*speed*dt;
    const length=Math.hypot(dx,dz);if(length>speed*dt&&length>0){dx*=speed*dt/length;dz*=speed*dt/length;}
    let collisions=0;
    if(dx){const nx=Math.max(-54,Math.min(54,camera.x+dx));if(!blockedAt(nx,camera.z))camera.x=nx;else collisions++;}
    if(dz){const nz=Math.max(-58,Math.min(42,camera.z+dz));if(!blockedAt(camera.x,nz))camera.z=nz;else collisions++;}
    camera.y=walkSurfaceHeight(camera.x,camera.z)+WALK_EYE_HEIGHT;
    lastCollisionEvents=collisions;
  }
  function drawPoints(vao,count,projection,view,color,size,soft){gl.useProgram(pointProgram);gl.uniformMatrix4fv(PU.uProjection,false,projection);gl.uniformMatrix4fv(PU.uView,false,view);gl.uniform1f(PU.uPointSize,size);gl.uniform3fv(PU.uPointColor,color);gl.uniform1f(PU.uSoft,soft);gl.bindVertexArray(vao);gl.drawArrays(gl.POINTS,0,count);gl.bindVertexArray(null);}
  function shouldRenderFrame(now){
    if(fpsLimit<=0){nextFrameTime=0;return true;}
    const interval=1000/fpsLimit;
    if(nextFrameTime>0 && now+0.5<nextFrameTime)return false;
    nextFrameTime=nextFrameTime>0?nextFrameTime+interval:now+interval;
    if(nextFrameTime<now-interval)nextFrameTime=now+interval;
    return true;
  }
  function render(now){
    if(!shouldRenderFrame(now)){requestAnimationFrame(render);return;}
    const cpuStart=performance.now();const dt=Math.min((now-last)/1000,.04);last=now;update(dt);frameCount++;fpsTimer+=dt;if(fpsTimer>=.5){fps=frameCount/fpsTimer;fpsLabel.textContent=Math.round(fps)+' FPS';frameCount=0;fpsTimer=0;}
    gl.enable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);gl.clearColor(.055,.09,.15,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    const eye=[camera.x,camera.y,camera.z],dir=[Math.sin(camera.yaw)*Math.cos(camera.pitch),Math.sin(camera.pitch),Math.cos(camera.yaw)*Math.cos(camera.pitch)];const center=[eye[0]+dir[0],eye[1]+dir[1],eye[2]+dir[2]];const view=lookAt(eye,center,[0,1,0]);const projection=perspective(Math.PI/3,canvas.width/canvas.height,.1,190);
    gl.useProgram(meshProgram);gl.uniformMatrix4fv(U.uProjection,false,projection);gl.uniformMatrix4fv(U.uView,false,view);gl.uniform3fv(U.uEye,eye);gl.uniform1f(U.uFogNear,20);gl.uniform1f(U.uFogFar,76);gl.uniform1i(U.uLampCount,Math.min(8,lampLights.length));const lp=[],lc=[];for(let i=0;i<Math.min(8,lampLights.length);i++){lp.push(...lampLights[i]);lc.push(...lampColors[i]);}gl.uniform3fv(U['uLampPos[0]'],new Float32Array(lp));gl.uniform3fv(U['uLampColor[0]'],new Float32Array(lc));
    for(const batch of sceneBatches){gl.bindVertexArray(batch.mesh.vao);gl.drawElementsInstanced(gl.TRIANGLES,batch.mesh.count,gl.UNSIGNED_INT,0,batch.count);}gl.bindVertexArray(null);
    // Stars stay visible above the horizon with a gently softened point sprite.
    gl.disable(gl.DEPTH_TEST);drawPoints(starVao,stars.length/3,projection,view,[.76,.85,1],2.0,.8);gl.enable(gl.DEPTH_TEST);
    const flakeData=new Float32Array(activeFlakeCount*3);for(let i=0;i<activeFlakeCount;i++){const f=flakes[i];f.y-=f.v*dt;f.x+=Math.sin(now*.00035+f.z)*.18*dt;if(f.y<.15){f.y=34;f.x=(Math.random()-.5)*75;f.z=(Math.random()-.5)*80;}flakeData[i*3]=f.x;flakeData[i*3+1]=f.y;flakeData[i*3+2]=f.z;}gl.bindBuffer(gl.ARRAY_BUFFER,flakeVbo);gl.bufferSubData(gl.ARRAY_BUFFER,0,flakeData);gl.disable(gl.DEPTH_TEST);drawPoints(flakeVao,activeFlakeCount,projection,view,[.83,.91,1],2.3,.72);gl.enable(gl.DEPTH_TEST);
    renderCpuMs=performance.now()-cpuStart;debugTimer+=dt;if(!document.getElementById('debugPanel').hidden&&debugTimer>=.2){debugTimer=0;document.getElementById('debugInfo').textContent=`FPS: ${Math.round(fps)}  |  Frame: ${(1000/Math.max(1,fps)).toFixed(1)} ms
Render CPU: ${renderCpuMs.toFixed(2)} ms
Quality: ${qualityProfiles[qualityMode].label}
Frame limit: ${fpsProfiles[fpsLimit].label}
Canvas: ${canvas.width} × ${canvas.height}
Player: X ${camera.x.toFixed(2)}  Y ${camera.y.toFixed(2)}  Z ${camera.z.toFixed(2)}
Ground height: ${(camera.y-WALK_EYE_HEIGHT).toFixed(3)}
Collision blocks this frame: ${lastCollisionEvents}
Solid colliders: ${colliders.length}
Scene instances: ${sceneInstanceCount}
Sakura body: ${(sakuraTreeMesh.count/3).toLocaleString()} tris per tree
Sakura snow: ${(sakuraSnowMesh.count/3).toLocaleString()} tris per tree
Sakura blossoms: ${sakuraBlossomInstanceCount.toLocaleString()} instances
Submitted triangles: ${Math.round(sceneTriangleCount).toLocaleString()}
Renderer: WebGL 2`;}
    requestAnimationFrame(render);
  }
  statusText.textContent='WEBGL2 ACTIVE · REAL-TIME SCENE';document.getElementById('rendererLabel').textContent='WebGL2';applyQuality('high',false);applyFrameLimit(0,false);requestAnimationFrame(render);
})();
