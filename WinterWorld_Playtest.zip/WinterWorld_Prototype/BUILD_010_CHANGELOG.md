# Build 010 — Changes

## Walkable cabin entry steps

- Removed the entry-step blocking collider. The steps are no longer treated as a solid wall.
- Added a dedicated stair-surface height calculation that follows the four visible treads. The player camera rises across the treads and descends when walking back down.
- Repositioned each tread vertically so its top matches the terrain at the outer end and rises in small increments toward the doorway. The highest tread aligns with the cabin door sill.
- Kept the cabin body collider in place. The player can climb to the doorway landing but cannot walk through the cabin wall; the interior and functional doorway are not built yet.
- Kept tree and lantern collision, obstacle sliding, path/snow ground following, fog, lighting, graphics presets, FPS caps, and diagnostics unchanged.

## Validation

- JavaScript syntax check: **passed**.
- Stair-surface helper checks: **passed** (four tread heights increase toward the doorway, the top tread aligns with the sill, and the player can reach the landing while the cabin wall remains blocking).
- Browser/GPU rendering and in-game climbing: requires the user's PC test. No visual runtime verification is claimed here.
