# Build 013 — M2 Forest Art Pass 3

## Implemented
- Rebuilt the sakura tree body with finer preservation of the authored trunk, pedicels, bark details, and closed buds.
- Split the authored snow deposits into their own shared GPU-instanced mesh instead of folding them into the coarse tree-body simplification.
- Increased sakura snow geometry detail from the Build 012 coarse simplification to a finer 0.0075 m vertex-cluster pass. The snow shell is expanded 2.5% horizontally and offset 4.5 mm along its authored normals to make small branch deposits more visible while keeping them aligned to the wood.
- Kept the existing individually instanced blossom placement and flower geometry unchanged; Build 012's blossom appearance already passed its specific user checks.
- Made conifer branch whorls less evenly spaced, varied each branch's length and droop, increased needle-spray sampling, and added short forked side twigs with their own needle sprays.
- Replaced the vague user-facing word “coherent” with plain close-up and distance-viewing descriptions in the testing checklist.

## Preserved
- Existing path, snow shoulders, rocks, sakura grove positions, cabin, lighting, fog, snowfall, controls, collision, stairs, ground following, quality presets, and FPS modes remain unchanged.
- The Build 012 blossom mesh and blossom placement count remain unchanged.

## Awaiting user testing
- Whether sakura branch snow now looks visibly fuller while remaining attached to branches.
- Whether small snow deposits are visible on more of the upper branch structure without creating floating white blobs.
- Whether sakura trunks, bark, and small twigs retain more natural detail at close range.
- Whether conifer branch layouts are less uniformly radial, with more naturally varied silhouettes.
- Whether new conifer forked twigs and foliage still read as connected tree structure at close and medium distances.
- Performance on High in the sakura grove and among the denser conifers.

## Not final
This remains an intermediate benchmark pass. PBR texture maps, detailed bark/needle/petal surface materials, physically based lighting, dynamic shadow maps, ambient occlusion, and hero-quality environmental assets are still future work. The current procedural conifers in particular are not final hero assets.

## Validation status
- JavaScript syntax, HTML/static references, mock WebGL initialization, first-frame submission, scene metrics, and ZIP integrity are to be checked for this package.
- Actual browser/GPU rendering and target-PC FPS remain unverified until user testing.

## Validation results
- `node --check src/main.js`: passed.
- `node --check src/sakura_mesh_data.js`: passed.
- Mock WebGL2 harness: initialized successfully and completed one frame.
- Scene metrics from the mock harness: 23,710 instances, 16 instanced batches, 5,406,222 submitted triangles, and 104 colliders.
- Sakura mesh per tree: 267,812 trunk/branch/pedicel/bud triangles plus 76,308 snow-shell triangles; 5,859 blossom instances per tree.
- Buffer uploads in the mock harness: approximately 22.35 MB. This is not a measured GPU VRAM allocation.
- The actual browser/GPU output and target-PC frame rate are not verified here and require the user's Build 013 test.
