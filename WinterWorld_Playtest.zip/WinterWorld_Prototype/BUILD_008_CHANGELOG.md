# Build 008 — Changes

- Player camera follows the procedural terrain, compacted path, and raised snow shoulders.
- Added collision with tree trunks, lantern posts, the cabin footprint, and entry steps.
- Movement resolves X/Z separately for obstacle sliding.
- Added High, Balanced, and Performance rendering presets.
- Added F3 diagnostics overlay.
- Removed the standalone test-report page; testing is performed in chat.
- Preserved the accepted scene geometry, path, cabin, fog, lighting, and controls.
