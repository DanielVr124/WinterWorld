# Winter World — Development Progress

## Current status

- **Latest build:** 013
- **Current milestone:** M2 — Quality Benchmark
- **Current sub-pass:** Forest Art Pass 3
- **M1 — Technical Foundation:** **Complete**, confirmed by user testing Build 010 (all A–E sections passed).
- **Build 011:** User review received; tree, branch snow, and forest floor sections need refinement. User reported about 60 FPS on High, but did not test all performance checklist items.
- **Build 012:** User review received. User confirmed blossoms, rocks, and new geometry functioned, but reported too little snow on sakura trees and said overall model quality remains low. User reported 60 FPS on High; no other detailed performance checks needed.
- **Build 013:** Finer separate sakura snow shell, higher-detail sakura trunk/twig/bud mesh, and less uniform conifer branch layout implemented; awaiting user visual/performance review.
- **Testing workflow:** all tests happen in this conversation. Only changed features and plausible regressions are requested for testing.

## M2 — Quality Benchmark

### Objective
Create one small, coherent forest-to-settlement area that establishes the art and performance standard for the rest of the world. The first forest is a benchmark, not the final world. A feature is not considered visually finished merely because it is present.

### Build 011 — Forest Art Pass 1

**Implemented**
- Replaced the cone-stack blockout evergreen with three shared conifer species meshes: broad spruce, narrow cedar-like evergreen, and young understory tree.
- Added gently curved tapered trunks, exposed branch whorls, overlapping foliage boughs, fine needle sprays, and irregular snow ribbons following the upper surfaces of the branches.
- Added instance size, orientation, and subtle tint variation.
- Added young growth beneath the main canopy to create a layered forest silhouette.
- Added snow-capped irregular rocks and a few fallen, partially buried limbs.
- Added subtle per-vertex material variation to the terrain, path, and snow shoulders.
- Updated terrain normals to follow the height function.
- Added two-sided diffuse response for thin foliage surfaces; material variation is carried in vertex colors to avoid expensive per-pixel noise.
- Extended F3 diagnostics with scene instance and estimated submitted triangle counts.

**Preserved from M1**
- Player controls, camera, pointer lock, sprint, movement speed, and ground following.
- Collision against mature tree trunks, lantern posts, cabin, and the climbable stairs.
- Cabin/roof geometry, path centerline and width, snow-shoulder positions, and their height profiles.
- Fog range, moon/stars, snowfall update, lantern locations, frame-rate modes, and quality presets.

**Awaiting user testing**
- Whether the new conifer shapes look substantially more natural than the previous cone-stack trees.
- Whether snowy branch clumps read as snow resting on branches rather than disconnected white blobs.
- Whether the added understory, rocks, and fallen limbs make the forest feel more layered without cluttering the path.
- Whether terrain/path/snow material variation looks natural and whether the accepted path remains visually clear.
- Whether the added larger snow-capped rocks block movement sensibly.
- Whether FPS remains acceptable on the target PC (GTX 1050 Ti 4 GB, Ryzen 5 5500, 8 GB RAM).

**Still not complete in M2**
- Photorealistic PBR material workflow and high-resolution bark/needle/snow textures.
- Dynamic shadow mapping and ambient occlusion.
- Hero-quality individual trees, moss, icicles, detailed rocks, and environmental prop assets.
- Forest lighting and atmospheric polish.
- Bakery exterior and fully modeled interior.
- First text-based open-ended baker NPC and persistence prototype.


### Build 011 validation

- JavaScript syntax check (`node --check`): **passed**.
- Mock-WebGL2 JavaScript runtime harness: **passed** initialization and first-frame submission.
- Runtime harness scene metrics: **270 scene instances**, **12 instanced mesh batches**, approximately **1,551,554 submitted triangles**, and **114 registered colliders**. Triangle count is the total across all scene instances, not only visible onscreen geometry.
- Buffer data uploaded during initialization: approximately **3.09 MB** in the mock runtime harness (includes mesh and auxiliary buffers; this is not a GPU memory measurement).
- Static HTML/DOM check: **passed**; all statically referenced element IDs exist and are unique.
- Cabin/path clearance checks were applied to newly placed rocks, understory trees, and fallen limbs by source logic; actual visual placement still needs user review.
- Actual browser/WebGL GPU rendering: **not verified in this container**; Chromium could not initialize its graphics context.
- User PC visuals and target-hardware performance: **awaiting Build 011 test**.

## M1 — Technical Foundation (complete)

The user tested Build 010 on their PC and passed every test in A–E:
- Application and controls: passed.
- Staircase: all four treads could be climbed and descended; camera height followed the stairs; cabin wall remained solid.
- Ground following: path, snow shoulders, and surrounding terrain passed.
- Settings and diagnostics: 30 FPS, 60 FPS, Unlocked, graphics presets, F3, player/collision diagnostics all passed.
- Performance: all frame modes and graphics presets remained smooth while walking and turning.

M1 is closed. Do not ask the user to routinely retest these unchanged systems in later builds. Only request regression tests if a change could plausibly affect them.

## User testing history

### Build 001
- Application launched; movement and mouse-look worked.
- A/D strafing was reversed.
- Base path, trees, timber building, moon/stars, snowfall and lanterns rendered.
- FPS was reported stable; E displayed the development note.
- Fog was not sufficiently obvious.

### Build 002
- A/D correction, roof shape, sign, snow path shoulders and fog passed.
- User observed gable-end wall gaps and path sitting too high.

### Build 003
- Controls, fog and performance passed.
- Gable panel alignment and path height needed additional work.

### Build 004
- Controls, fog and performance passed.
- Building still needed repair; path was partially passed.

### Build 005
- Controls, path/snow, atmosphere and performance passed.
- Gable infill panels were still on the wrong sides.

### Build 006
- All five sections passed; gable geometry and path were accepted.

### Build 007
- A separate test-report webpage was briefly added. User requested that testing happen directly in chat; the local page was removed and must not be reintroduced unless explicitly requested.

### Build 008
- Controls, collision, ground following, settings, diagnostics and performance passed.
- User requested Unlocked FPS.

### Build 009
- User confirmed the stair shape/direction and FPS modes, but could not walk up the steps.

### Build 010
- User confirmed all five sections passed, including climbing and descending all four steps, ground following, collision, settings, F3 diagnostics, and performance.
- This completed M1.

## Permanent reporting conventions

- Every build comes with a download, change summary, validation status, and a chat-based testing checklist.
- Every milestone report separates implemented, user-confirmed, awaiting-test, and unfinished work.
- Only test newly changed code/content and plausible regressions. Do not retest unchanged, previously verified systems as busywork.
- Chat testing uses A–E sections, each with a section result, a Select all control, individual checks, and a dedicated free-text notes field.
- Never claim runtime/visual verification on the user's hardware unless the user has actually tested it.
- Do not claim photorealistic quality for a blockout or early procedural pass. Treat visual quality as something to prove and improve.


### Build 012 — Forest Art Pass 2

**Implemented**
- Added a four-tree Japanese sakura grove using a simplified mesh derived from the detailed cherry-tree asset already available in the project files.
- The base mesh preserves mature bark/branch structure, fine pedicels, buds, settled snow, vertex colors and smooth normals. The original 45 MB GLB is not shipped.
- Added 5,859 instanced five-petal blossoms per tree (23,436 total for four trees), sampled from the source model's original flower placement transforms.
- Refined conifer bough/needle density and branch-following snow caps.
- Refined boulder profiles and snow/mineral breakup; added a second rock variant and small embedded stones.
- Preserved clearance around the sakura grove and added trunk collision volumes.

**Awaiting user testing**
- Sakura model/grove appearance and blossom density.
- Snow placement on sakura branches and conifer boughs.
- Conifer foliage fullness and silhouette variety.
- Rock shapes and integration with the forest floor.
- Performance in the newly dense grove, especially High preset.

**Not final**
- PBR bark/needle/petal textures, high-frequency snow detail, dynamic shadows, ambient occlusion, forest-lighting polish, and hero assets remain future M2 work.

### Build 012 validation

- `node --check src/main.js`: **passed**.
- `node --check src/sakura_mesh_data.js`: **passed**.
- Mock WebGL2 runtime harness: **passed** initialization and first-frame submission.
- Scene metrics from mock runtime harness: **23,706 scene instances**, **15 instanced mesh batches**, **3,537,982 submitted triangles**, **104 colliders**.
- Sakura mesh: **117,660 base triangles per tree**; **5,859 blossom instances per tree**; four grove trees.
- Mesh/scene buffer uploads in the harness: approximately **11.80 MB** (upload totals in this mock context, not a measured VRAM allocation).
- Actual browser/GPU visual rendering: **not verified in this container**; user visual review remains required.
- Target-PC FPS: **awaiting Build 012 user test**.


### Build 013 — Forest Art Pass 3

**Implemented**
- Split sakura snow deposits into a separate shared mesh, using a much finer source-mesh reduction to retain smaller snow clumps that the previous coarse simplification discarded.
- Expanded the sakura snow shell 2.5% horizontally and offset it 4.5 mm along authored normals for visibility without intentionally detaching it from branches.
- Increased detail retention for the sakura's mature bark, pedicels, lenticels, and buds.
- Kept the Build 012 five-petal blossom mesh and sampled blossom placements unchanged because the user passed those blossom checks.
- Changed conifer branch whorl angles, branch lengths, droop, needle-spray spacing, and forked side twigs to reduce the evenly repeated radial silhouette.
- Simplified testing language: replace “coherent” with explicit close-up branch and distance silhouette observations.

**Awaiting user testing**
- Sakura snow coverage and attachment.
- Sakura bark/twig detail in close view.
- Less repetitive conifer structure and silhouette.
- Performance of the added tree detail on High.

**Not final**
- These are still intermediate game meshes, not final hero assets. PBR texture maps, detailed bark/needle/petal materials, dynamic shadows, ambient occlusion, and lighting polish remain future M2 work. The procedural conifers are still placeholders for eventual higher-quality hero assets.

### Build 012 user feedback
- User confirmed all tested rock and forest-floor checks passed.
- User confirmed the blossom density, blossom attachment, and individual petal readability passed.
- User reported too little snow on sakura branches.
- User marked tree detail and some conifer checks as not checked, and expressed that overall tree-model quality still looked low.
- User reported 60 FPS on High and passed all performance tests.


### Build 013 user feedback
- Sakura body and blossom checks passed.
- Sakura snow was accepted but reported as less noticeable from ground level.
- Conifer foliage fullness, snow-cap presence, distance appearance, and branch/foliage connectivity passed; branch layout variety and lighting-related visual checks were not confirmed.
- Rock and forest-floor checks passed.
- Performance checks passed at approximately 60 FPS on High, including standing, walking, turning, and dense blossom views.
- Overall: user still considers the forest visually low quality and requests substantial upgrades.

### Build 014 — M2 Forest Art Pass 4

**Implemented**
- Re-authored the three conifer species with more distinctive silhouettes: dense tapered spruce, broader drooping cedar, and irregular open fir.
- Introduced per-level branch phase shifts, irregular branch counts, larger variation in branch lengths and droop, asymmetry, small vertical offsets, and occasional missing branches to disrupt repeated radial tiers.
- Increased side-branch complexity and varied fork lengths/positions, needle sprays, and exposed twig placement.
- Widened/deepened conifer branch-snow pillows and made their edges less uniform.
- Added a restrained cool snow-surface light term to improve branch-snow readability under night lighting.

**Preserved**
- Sakura body/snow/blossom meshes and placements, rocks, forest floor, terrain, path, snow shoulders, cabin, movement, collision, stairs, graphics presets, FPS settings, fog, stars, moon, snowfall, and user controls.

**Awaiting user testing**
- Distinctness and naturalness of the three conifer silhouettes.
- Branch spacing, length variation, forks, needle sprays, and foliage integration.
- Branch snow visibility from player height and its appearance under the night lighting.
- Performance in dense conifer views on High.

**Validation**
- `node --check src/main.js`: passed.
- `node --check src/sakura_mesh_data.js`: passed.
- Mock WebGL2 initialization and one scheduled frame: passed.
- Scene metrics from the mock harness: 23,710 instances, 16 instanced batches, 5,435,550 submitted triangles, 104 colliders. Per-species conifer mesh sizes: 38,532; 34,716; and 25,752 triangles. Sakura body, snow, blossoms, and placements remain unchanged from Build 013.
- Mock-harness uploaded buffer data: approximately 22.66 MB. This is not measured physical VRAM usage.
- Actual target-PC visual rendering/FPS: awaiting user testing.

**Not final**
- The conifers remain procedural intermediate meshes and are not final hero assets. High-resolution bark/needle material maps, PBR response, dynamic shadows, ambient occlusion, and art-directed hero vegetation remain future work.
