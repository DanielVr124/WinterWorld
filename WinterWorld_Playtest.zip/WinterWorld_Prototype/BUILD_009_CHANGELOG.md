# Build 009 — Changes

- Reversed the decorative entry-step height progression: the outermost tread is now lowest and treads rise toward the cabin doorway.
- Kept the entry-step collider and all previously accepted cabin, roof, path, snow, fog, lighting, and environment geometry unchanged.
- Added 30 FPS and 60 FPS app-side caps plus an Unlocked mode with no additional app-side cap (default).
- Added frame-limit selection and a clear explanation that browser `requestAnimationFrame` remains display/browser scheduled; Unlocked does not bypass V-Sync or the monitor refresh ceiling.
- Added the selected frame-limit mode to the F3 diagnostics overlay.
- Kept all testing in chat; no separate local testing form is included.
