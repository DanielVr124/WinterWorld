#!/usr/bin/env python3
"""Headless Blender Cycles render setup for Winter World Hero Spruce V52.

Run from Blender 5.2+ in background mode. The tree and bough GLBs must sit
beside this script. The generator is reproducible from the V47/V52 source.
"""
import bpy
import json
import math
import os
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
TREE_GLB = os.path.join(HERE, "Hero_Spruce_V52_GameLOD.glb")
BOUGH_GLB = os.path.join(HERE, "Hero_Spruce_V52_Bough.glb")
OUT = os.path.join(HERE, "cycles_renders")
os.makedirs(OUT, exist_ok=True)

if not os.path.isfile(TREE_GLB) or not os.path.isfile(BOUGH_GLB):
    raise FileNotFoundError("V52 tree and bough GLBs must exist beside this script")


def clear_scene():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials,
                       bpy.data.cameras, bpy.data.lights):
        for block in list(datablocks):
            if block.users == 0:
                datablocks.remove(block)


def add_vertex_color_pbr(name, attr_name, roughness, noise_scale, bump_strength,
                         bump_distance, subsurface=0.0, coat=0.0):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new('ShaderNodeOutputMaterial')
    out.location = (700, 80)
    bs = nodes.new('ShaderNodeBsdfPrincipled')
    bs.location = (420, 80)
    bs.inputs['Roughness'].default_value = roughness
    sub = bs.inputs.get('Subsurface Weight') or bs.inputs.get('Subsurface')
    if sub is not None:
        sub.default_value = subsurface
    coat_input = bs.inputs.get('Coat Weight') or bs.inputs.get('Clearcoat')
    if coat_input is not None:
        coat_input.default_value = coat

    color = nodes.new('ShaderNodeVertexColor')
    color.layer_name = attr_name
    color.location = (-450, 180)
    noise = nodes.new('ShaderNodeTexNoise')
    noise.location = (-450, -120)
    noise.inputs['Scale'].default_value = noise_scale
    noise.inputs['Detail'].default_value = 5.0
    noise.inputs['Roughness'].default_value = 0.78
    bump = nodes.new('ShaderNodeBump')
    bump.location = (150, -90)
    bump.inputs['Strength'].default_value = bump_strength
    bump.inputs['Distance'].default_value = bump_distance
    links.new(color.outputs['Color'], bs.inputs['Base Color'])
    links.new(noise.outputs['Fac'], bump.inputs['Height'])
    links.new(bump.outputs['Normal'], bs.inputs['Normal'])
    links.new(bs.outputs['BSDF'], out.inputs['Surface'])
    return mat


def assign_materials(imported_objects):
    for obj in imported_objects:
        if obj.type != 'MESH':
            continue
        attrs = getattr(obj.data, 'color_attributes', None)
        attr = attrs.active_color if attrs and attrs.active_color else (attrs[0] if attrs and len(attrs) else None)
        attr_name = attr.name if attr else 'Color'
        name = obj.name.lower()
        if 'snow' in name:
            mat = add_vertex_color_pbr('Snow | softly packed granular powder', attr_name,
                                       0.84, 105.0, 0.17, 0.006, 0.035, 0.0)
            for p in obj.data.polygons:
                p.use_smooth = True
        elif 'needle' in name:
            mat = add_vertex_color_pbr('Spruce needles | waxed blue-green', attr_name,
                                       0.68, 165.0, 0.08, 0.0014, 0.012, 0.12)
            # Keep the fine individual needles crisp rather than averaging their faces.
            for p in obj.data.polygons:
                p.use_smooth = False
        else:
            mat = add_vertex_color_pbr('Bark and woody branchlets | ridged spruce', attr_name,
                                       0.9, 38.0, 0.25, 0.014, 0.0, 0.0)
            for p in obj.data.polygons:
                p.use_smooth = True
        obj.data.materials.clear()
        obj.data.materials.append(mat)


def setup_world_and_lights(scene):
    world = bpy.data.worlds.new('Winter dusk | cool ambient')
    world.use_nodes = True
    world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.055, 0.085, 0.13, 1)
    world.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.34
    scene.world = world

    def area(name, location, power, color, size, target=(0, 4.0, 0)):
        data = bpy.data.lights.new(name, 'AREA')
        data.energy = power
        data.color = color
        data.shape = 'DISK'
        data.size = size
        obj = bpy.data.objects.new(name, data)
        scene.collection.objects.link(obj)
        obj.location = location
        obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z', 'Y').to_euler()
        return obj

    area('Large soft warm winter key', (5.5, 10.5, 8.0), 3200, (1.0, 0.88, 0.77), 7.0)
    area('Cool sky fill', (-7.0, 7.0, 2.0), 2400, (0.70, 0.83, 1.0), 8.0)
    area('Blue snow rim', (1.0, 8.5, -9.0), 3600, (0.74, 0.86, 1.0), 6.0)
    area('Soft frontal detail fill', (0.0, 4.5, 12.0), 850, (0.86, 0.92, 1.0), 9.0)

    # Y is the tree's up axis; rotate the default XY plane to face +Y.
    bpy.ops.mesh.primitive_plane_add(size=200, location=(0, -0.105, 0))
    floor = bpy.context.object
    floor.name = 'Matte snow studio floor'
    floor.rotation_euler[0] = math.radians(-90)
    floor_mat = bpy.data.materials.new('Snow floor | matte blue-white')
    floor_mat.use_nodes = True
    floor_bs = floor_mat.node_tree.nodes.get('Principled BSDF')
    floor_bs.inputs['Base Color'].default_value = (0.42, 0.55, 0.68, 1)
    floor_bs.inputs['Roughness'].default_value = 0.94
    floor.data.materials.append(floor_mat)


def make_camera(name, location, target, lens, sensor_height=36.0):
    data = bpy.data.cameras.new(name)
    obj = bpy.data.objects.new(name, data)
    bpy.context.scene.collection.objects.link(obj)
    obj.location = location
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z', 'Y').to_euler()
    data.lens = lens
    data.sensor_fit = 'VERTICAL'
    data.sensor_height = sensor_height
    return obj


def configure_cycles(scene, samples, width, height):
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = samples
    scene.cycles.use_denoising = True
    scene.cycles.use_adaptive_sampling = True
    scene.cycles.adaptive_threshold = 0.025
    scene.cycles.max_bounces = 8
    scene.cycles.diffuse_bounces = 3
    scene.cycles.glossy_bounces = 3
    scene.render.resolution_x = width
    scene.render.resolution_y = height
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'
    scene.view_settings.view_transform = 'AgX'
    try:
        scene.view_settings.look = 'AgX - Medium High Contrast'
    except Exception:
        pass
    scene.render.film_transparent = False
    scene.render.threads_mode = 'FIXED'
    scene.render.threads = max(1, min(8, os.cpu_count() or 4))


def render_to(scene, camera, filename, samples, width, height):
    configure_cycles(scene, samples, width, height)
    scene.camera = camera
    scene.render.filepath = os.path.join(OUT, filename)
    print('CYCLES_RENDER_START', filename, 'samples=', samples, 'resolution=', width, 'x', height, flush=True)
    bpy.ops.render.render(write_still=True)
    print('CYCLES_RENDER_COMPLETE', filename, flush=True)


# Main full-tree studio scene.
clear_scene()
scene = bpy.context.scene
bpy.ops.import_scene.gltf(filepath=TREE_GLB)
tree_objects = [o for o in scene.objects if o.type == 'MESH']
assign_materials(tree_objects)
setup_world_and_lights(scene)
full_camera = make_camera('Hero three-quarter camera', (10.5, 7.4, 14.0), (0.05, 4.05, -0.05), 46.0)
back_camera = make_camera('Opposite three-quarter camera', (-11.0, 8.6, -13.0), (0.0, 4.0, 0.0), 43.0)
render_to(scene, full_camera, 'V52_Cycles_FullTree_ThreeQuarter.png', 48, 1600, 1900)
render_to(scene, back_camera, 'V52_Cycles_FullTree_ReverseAngle.png', 32, 1300, 1550)

# Hide the large tree and bring in the standalone bough for a true geometry close-up.
for obj in tree_objects:
    obj.hide_render = True
bpy.ops.import_scene.gltf(filepath=BOUGH_GLB)
bough_objects = [o for o in scene.objects if o.type == 'MESH' and o not in tree_objects]
assign_materials(bough_objects)
# Move the branch slightly above the studio floor so its full underside is visible.
for obj in bough_objects:
    obj.location.y += 0.50
bough_camera = make_camera('Bough macro camera', (1.05, 1.55, 4.15), (1.03, 0.08, 0.0), 66.0)
render_to(scene, bough_camera, 'V52_Cycles_Bough_Closeup.png', 64, 1700, 1150)

# Save a reusable native scene. It contains both the tree and close-up bough assets.
blend_path = os.path.join(HERE, 'Hero_Spruce_V52_Cycles.blend')
bpy.ops.wm.save_as_mainfile(filepath=blend_path)

manifest = {
    'renderer': 'Blender Cycles',
    'blender_version': bpy.app.version_string,
    'device': 'CPU',
    'tree_mesh_objects': len(tree_objects),
    'bough_mesh_objects': len(bough_objects),
    'outputs': [
        'V52_Cycles_FullTree_ThreeQuarter.png',
        'V52_Cycles_FullTree_ReverseAngle.png',
        'V52_Cycles_Bough_Closeup.png',
        'Hero_Spruce_V52_Cycles.blend'
    ],
    'notes': 'These images are genuine Blender Cycles renders of the supplied V52 GLB geometry.'
}
with open(os.path.join(OUT, 'CYCLES_RENDER_MANIFEST.json'), 'w', encoding='utf-8') as f:
    json.dump(manifest, f, indent=2)
print('CYCLES_RENDER_ALL_COMPLETE', json.dumps(manifest), flush=True)
