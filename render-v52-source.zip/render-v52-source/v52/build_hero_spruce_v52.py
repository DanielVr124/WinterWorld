#!/usr/bin/env python3
"""Generate a realistic, snow-laden Norway spruce for Winter World.

Outputs:
  Hero_Spruce_V52_GameLOD.glb       high-detail hero tree
  Hero_Spruce_V52_GameLOD.glb    optimized reusable forest mesh
  Hero_Spruce_V52_Bough.glb      close-up reusable evergreen bough
  hero_spruce_mesh_data.js       compact browser mesh data for the game LOD
  Hero_Spruce_V52_Blender_Setup.py Blender import / scene / render script

Requires Python 3, numpy, trimesh. All dimensions are meters, Y up.
"""
from __future__ import annotations
import base64, gzip, json, math, os, random, struct
from pathlib import Path
import numpy as np
import trimesh

OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)

PALETTE = {
    'bark': np.array([[0.105,0.070,0.050],[0.16,0.100,0.067],[0.205,0.132,0.085],[0.075,0.060,0.047]], dtype=float),
    'twig': np.array([[0.13,0.085,0.058],[0.19,0.125,0.080],[0.25,0.165,0.105]], dtype=float),
    'needle': np.array([[0.022,0.105,0.080],[0.030,0.155,0.112],[0.046,0.205,0.145],[0.068,0.265,0.180],[0.105,0.330,0.220],[0.155,0.385,0.265]], dtype=float),
    'snow': np.array([[0.83,0.89,0.95],[0.91,0.94,0.98],[0.74,0.83,0.91],[0.97,0.98,1.0]], dtype=float),
}


def unit(v):
    v = np.asarray(v, dtype=float)
    n = np.linalg.norm(v)
    return v / (n if n > 1e-10 else 1.0)


def frame_from_axis(axis):
    axis = unit(axis)
    ref = np.array([0.,1.,0.]) if abs(axis[1]) < 0.92 else np.array([1.,0.,0.])
    u = unit(np.cross(axis, ref))
    v = unit(np.cross(axis, u))
    return u, v, axis


class Builder:
    def __init__(self, name):
        self.name = name
        self.v = []
        self.f = []
        self.c = []

    def add_vertex(self, p, c):
        self.v.append(np.asarray(p, dtype=np.float32))
        self.c.append(np.asarray(c, dtype=np.float32))

    def add_tube(self, points, radii, color='twig', sides=7, seed=0, ridged=0.0):
        points = [np.asarray(p, dtype=float) for p in points]
        radii = list(radii)
        first = len(self.v)
        rng = random.Random(seed)
        rings = []
        for i, (p, radius) in enumerate(zip(points, radii)):
            if i == 0: tangent = unit(points[1]-points[0])
            elif i == len(points)-1: tangent = unit(points[-1]-points[-2])
            else: tangent = unit(points[i+1]-points[i-1])
            u, vv, _ = frame_from_axis(tangent)
            ring=[]
            for j in range(sides):
                a=2*math.pi*j/sides
                wave = 1.0 + ridged*(0.52*math.sin(a*5+seed*.37)+0.22*math.sin(a*11-seed*.21))
                rr=max(0.0008, radius*wave)
                q=p+rr*(math.cos(a)*u+math.sin(a)*vv)
                base = PALETTE[color][(i+j+seed)%len(PALETTE[color])].copy()
                var = 0.88 + 0.22*rng.random()
                self.add_vertex(q, np.clip(base*var,0,1))
                ring.append(len(self.v)-1)
            rings.append(ring)
        for i in range(len(rings)-1):
            for j in range(sides):
                a=rings[i][j]; b=rings[i][(j+1)%sides]
                c=rings[i+1][j]; d=rings[i+1][(j+1)%sides]
                self.f.extend([(a,b,c),(b,d,c)])
        # Triangulated end caps prevent open tips on thick branches.
        for j in range(1, sides-1):
            self.f.append((rings[0][0], rings[0][j+1], rings[0][j]))
            self.f.append((rings[-1][0], rings[-1][j], rings[-1][j+1]))

    def add_needle(self, start, direction, length, width, color_idx, seed=0):
        rng=random.Random(seed)
        d=unit(direction)
        u,v,_=frame_from_axis(d)
        twist=rng.random()*math.pi*2
        uu=math.cos(twist)*u+math.sin(twist)*v
        vv=-math.sin(twist)*u+math.cos(twist)*v
        w=width
        h=width*0.36
        base=np.asarray(start,dtype=float)
        # A slender four-sided spruce needle, tapering to a sharp tip.
        ring=[base+uu*w+vv*h, base-uu*w+vv*h, base-uu*w-vv*h, base+uu*w-vv*h]
        tip=base+d*length
        ci=PALETTE['needle'][color_idx % len(PALETTE['needle'])]
        ci2=np.clip(ci*1.18+np.array([.012,.018,.008]),0,1)
        first=len(self.v)
        for p in ring: self.add_vertex(p,ci)
        self.add_vertex(tip,ci2)
        self.f.extend([(first,first+1,first+4),(first+1,first+2,first+4),
                       (first+2,first+3,first+4),(first+3,first,first+4),
                       (first+3,first+2,first+1),(first+3,first+1,first)])

    def add_spray(self, center, axis, count, length, seed, scale=1.0):
        # Vectorized needle rosette: preserves individual tapered needles while
        # avoiding one Python object/method call per leaf.
        rng=np.random.default_rng(seed)
        axis=unit(axis); u,v,_=frame_from_axis(axis)
        phase=rng.random()*math.tau
        angles=phase+np.arange(count)*math.tau/count+rng.uniform(-.18,.18,count)
        radial=np.cos(angles)[:,None]*u[None,:]+np.sin(angles)[:,None]*v[None,:]
        axial=rng.uniform(.19,.39,count)[:,None]
        dirs=radial*rng.uniform(.78,1.05,(count,1))+axis[None,:]*axial
        dirs+=np.column_stack([np.zeros(count),rng.uniform(-.12,.20,count),np.zeros(count)])
        dirs/=np.maximum(np.linalg.norm(dirs,axis=1,keepdims=True),1e-10)
        refs=np.tile(np.array([0.,1.,0.]),(count,1))
        refs[np.abs(dirs[:,1])>=.92]=np.array([1.,0.,0.])
        uu=np.cross(dirs,refs); uu/=np.maximum(np.linalg.norm(uu,axis=1,keepdims=True),1e-10)
        vv=np.cross(dirs,uu)
        twists=rng.random(count)*math.pi*2
        u2=np.cos(twists)[:,None]*uu+np.sin(twists)[:,None]*vv
        v2=-np.sin(twists)[:,None]*uu+np.cos(twists)[:,None]*vv
        offsets=radial*rng.uniform(.004,.018,(count,1))*scale
        bases=np.asarray(center,dtype=float)[None,:]+offsets
        lens=length*rng.uniform(.76,1.24,count)*scale
        widths=lens*rng.uniform(.035,.055,count)
        heights=widths*.36
        verts=np.empty((count,5,3),dtype=np.float32)
        verts[:,0]=bases+u2*widths[:,None]+v2*heights[:,None]
        verts[:,1]=bases-u2*widths[:,None]+v2*heights[:,None]
        verts[:,2]=bases-u2*widths[:,None]-v2*heights[:,None]
        verts[:,3]=bases+u2*widths[:,None]-v2*heights[:,None]
        verts[:,4]=bases+dirs*lens[:,None]
        palette=PALETTE['needle']
        color_idx=rng.integers(0,len(palette),count)
        colors=palette[color_idx]
        colors2=np.clip(colors*1.18+np.array([.012,.018,.008]),0,1)
        cols=np.empty((count,5,3),dtype=np.float32)
        cols[:,:4]=colors[:,None,:]; cols[:,4]=colors2
        base=len(self.v)
        self.v.extend(verts.reshape((-1,3)))
        self.c.extend(cols.reshape((-1,3)))
        offsets_i=base+np.arange(count,dtype=np.uint32)*5
        local_faces=np.array([[0,1,4],[1,2,4],[2,3,4],[3,0,4],[3,2,1],[3,1,0]],dtype=np.uint32)
        faces=(offsets_i[:,None,None]+local_faces[None,:,:]).reshape((-1,3))
        self.f.extend(faces)

    def add_foliage_cluster(self, center, axis, lateral, count, seed, scale=1.0, length=.085):
        # A compact 3D cloud of individually modeled needles. Starts are scattered
        # through the bough volume, not all pinned to one point like a starburst.
        rng=np.random.default_rng(seed)
        axis=unit(axis); lateral=unit(lateral); up=np.array([0.,1.,0.])
        side_extent=.22*scale; up_extent=.25*scale; axial_extent=.13*scale
        bases=np.asarray(center,dtype=float)[None,:]
        bases=bases + axis[None,:]*rng.uniform(-axial_extent,axial_extent,(count,1))
        bases=bases + lateral[None,:]*rng.uniform(-side_extent,side_extent,(count,1))
        bases=bases + up[None,:]*rng.uniform(-up_extent,up_extent,(count,1))
        dirs=axis[None,:]*rng.uniform(.52,.88,(count,1))
        dirs+=lateral[None,:]*rng.uniform(-.62,.62,(count,1))
        dirs+=up[None,:]*rng.uniform(-.38,.72,(count,1))
        dirs/=np.maximum(np.linalg.norm(dirs,axis=1,keepdims=True),1e-10)
        refs=np.tile(up,(count,1)); refs[np.abs(dirs[:,1])>=.92]=np.array([1.,0.,0.])
        uu=np.cross(dirs,refs); uu/=np.maximum(np.linalg.norm(uu,axis=1,keepdims=True),1e-10)
        vv=np.cross(dirs,uu)
        twist=rng.random(count)*math.tau
        u2=np.cos(twist)[:,None]*uu+np.sin(twist)[:,None]*vv
        v2=-np.sin(twist)[:,None]*uu+np.cos(twist)[:,None]*vv
        lens=length*scale*rng.uniform(.70,1.32,count)
        widths=lens*rng.uniform(.035,.055,count); heights=widths*.36
        verts=np.empty((count,5,3),dtype=np.float32)
        verts[:,0]=bases+u2*widths[:,None]+v2*heights[:,None]
        verts[:,1]=bases-u2*widths[:,None]+v2*heights[:,None]
        verts[:,2]=bases-u2*widths[:,None]-v2*heights[:,None]
        verts[:,3]=bases+u2*widths[:,None]-v2*heights[:,None]
        verts[:,4]=bases+dirs*lens[:,None]
        palette=PALETTE['needle']; ci=rng.integers(0,len(palette),count)
        colors=palette[ci]; bright=np.clip(colors*1.16+np.array([.010,.016,.008]),0,1)
        cols=np.empty((count,5,3),dtype=np.float32); cols[:,:4]=colors[:,None,:]; cols[:,4]=bright
        base=len(self.v); self.v.extend(verts.reshape((-1,3))); self.c.extend(cols.reshape((-1,3)))
        offsets=base+np.arange(count,dtype=np.uint32)*5
        faces=(offsets[:,None,None]+np.array([[0,1,4],[1,2,4],[2,3,4],[3,0,4],[3,2,1],[3,1,0]],dtype=np.uint32)[None,:,:]).reshape((-1,3))
        self.f.extend(faces)

    def add_snow_ribbon(self, points, half_width, thickness, lift, seed,
                        segments=20, start=0.0, end=1.0, support_radii=None):
        """A sculpted, branch-conforming snow mantle with a rounded, irregular top.

        The deposit is a continuous surface strip, not a detached blob. Its width
        tracks the local bough direction, its edges scallop irregularly, and its
        height varies gently like wind-settled powder. The cap is deliberately
        fuller than V47 and extends over the outer needle spray while keeping the
        lower edge above the branch silhouette.
        """
        pts=[np.asarray(p,dtype=float) for p in points]
        radius_values=np.asarray(support_radii,dtype=float) if support_radii is not None else None
        if radius_values is not None and (radius_values.shape != (len(pts),) or np.any(radius_values <= 0)):
            raise ValueError('support_radii must contain one positive radius for every ribbon path point')
        if len(pts)<2 or end<=start: return
        rng=np.random.default_rng(seed)
        lengths=np.array([np.linalg.norm(pts[i+1]-pts[i]) for i in range(len(pts)-1)])
        cumulative=np.concatenate([[0.0],np.cumsum(lengths)])
        total=float(cumulative[-1])
        if total<1e-5: return
        cross=np.linspace(-1.0,1.0,21,dtype=float)
        # Broad crown: relatively full top, softly rolled shoulders, feathered edge.
        crown=np.maximum(0.0,1.0-np.abs(cross)**1.55)**0.58
        verts=[]; cols=[]
        snow_palette=PALETTE['snow']
        base_color=snow_palette[int(rng.integers(0,len(snow_palette)))]
        phase=float(rng.uniform(0,math.tau))
        edge_phase=float(rng.uniform(0,math.tau))
        # A few low-frequency random stations create non-repeating natural edges.
        station_noise=rng.uniform(-.105,.105,segments+1)
        for i in range(segments+1):
            u=i/segments
            path_u=start+(end-start)*u
            dist=path_u*total
            seg=min(len(pts)-2,max(0,int(np.searchsorted(cumulative,dist,side='right')-1)))
            seg_len=max(1e-8,lengths[seg])
            f=np.clip((dist-cumulative[seg])/seg_len,0.0,1.0)
            support_radius=None
            if radius_values is not None:
                support_radius=float(radius_values[seg]*(1-f)+radius_values[seg+1]*f)
            center=pts[seg]*(1-f)+pts[seg+1]*f
            # Tangent from the local branch curve, not a single global direction.
            lo=max(0.0,dist-total*.018); hi=min(total,dist+total*.018)
            def at_distance(d):
                k=min(len(pts)-2,max(0,int(np.searchsorted(cumulative,d,side='right')-1)))
                ff=np.clip((d-cumulative[k])/max(1e-8,lengths[k]),0.0,1.0)
                return pts[k]*(1-ff)+pts[k+1]*ff
            tangent=unit(at_distance(hi)-at_distance(lo))
            up=np.array([0.,1.,0.])
            side=unit(np.cross(up,tangent))
            if np.linalg.norm(side)<.15:
                side=unit(np.cross(np.array([0.,0.,1.]),tangent))
            if np.linalg.norm(side)<.15: side=np.array([1.,0.,0.])
            # More snow settles on flatter, upward-facing branch sections.
            flatness=1.0-min(.38,abs(float(tangent[1]))*.52)
            longitudinal=np.sin(np.pi*u)**.22
            edge_wave=(.92+.085*np.sin(u*math.tau*1.7+phase)
                       +.060*np.sin(u*math.tau*4.3-phase*.6)+station_noise[i])
            width=half_width*longitudinal*edge_wave*flatness
            # Shallow banked powder with a little drift and micro-relief.
            waviness=(.0034*np.sin(u*math.tau*2.6+phase)
                      +.0020*np.sin(u*math.tau*7.4+phase*.5)
                      +float(rng.uniform(-.0009,.0009)))
            contact_lift=lift
            if support_radius is not None:
                # Embed the snow's lower edge slightly into the supporting wood.
                # Clamp micro-relief to the local radius so thin tips cannot float.
                contact_lift=min(lift,support_radius*.88)
                waviness=float(np.clip(waviness,-support_radius*.04,support_radius*.04))
            base_y=center[1]+contact_lift+waviness
            local_thickness=thickness*(.82+.16*np.sin(u*math.tau*1.8+phase)
                                       +float(rng.uniform(-.045,.045)))*flatness
            for j,x in enumerate(cross):
                # Slightly irregular shoulders; the surface stays inside the needle canopy.
                side_mod=1.0+.035*np.sin(u*math.tau*4.0+x*2.6+edge_phase)
                side_mod+=.018*np.sin(u*math.tau*8.0-x*4.2+phase)
                lateral=x*width*side_mod
                surface_ripple=(.0040*np.sin(u*math.tau*4.8+x*math.pi*2+phase)
                                +.0018*np.sin(u*math.tau*9.0-x*math.pi*3+edge_phase)
                                +float(rng.uniform(-.00035,.00035)))
                p=center+up*(base_y-center[1]+local_thickness*crown[j]+surface_ripple*crown[j]) + side*lateral
                verts.append(p)
                # Snow is brightest on the rounded crown and cooler at the feathered edge.
                edge=abs(float(x))
                shade=(1.015-.055*edge)+.018*np.sin(u*math.tau*3+x*1.3+phase)
                color=base_color*shade
                if edge>.78: color=color*np.array([.985,.995,1.025])
                cols.append(np.clip(color,0,1))
        base=len(self.v)
        for p,c in zip(verts,cols): self.add_vertex(p,c)
        for i in range(segments):
            for j in range(len(cross)-1):
                a=base+i*len(cross)+j
                b=base+(i+1)*len(cross)+j
                c=a+1; d=b+1
                self.f.extend([(a,b,c),(c,b,d)])

    def add_snow_clump(self, center, axis, length, width, height, seed):
        rng=random.Random(seed)
        # A softly domed, uneven snow pillow with a compressed underside.
        # The higher-resolution surface and nonuniform edge break up the old
        # repeated pancake silhouette while keeping each deposit lightweight.
        mesh=trimesh.creation.icosphere(subdivisions=3, radius=1.0)
        local=mesh.vertices.copy()
        vv=np.empty_like(local)
        for i,(x,y,z) in enumerate(local):
            rough=rng.uniform(.90,1.10)
            yy=y*(.34 if y < -.10 else (0.82 if y < .18 else 1.0))
            xx=x*rough + .045*math.sin(y*4.0+seed*.13)*(1-abs(x))
            zz=z*rng.uniform(.92,1.08)
            vv[i]=[xx,yy,zz]
        axis=unit(axis)
        side=unit(np.cross(axis,np.array([0.,1.,0.])))
        if np.linalg.norm(side)<.1: side=np.array([1.,0.,0.])
        up=unit(np.cross(side,axis))
        mat=np.column_stack([axis,up,side])
        vv=vv @ mat.T
        vv*=np.array([length,width*0.52,height])
        vv+=np.asarray(center)
        offset=len(self.v)
        col=PALETTE['snow'][rng.randrange(len(PALETTE['snow']))]
        for p in vv:
            var=rng.uniform(.95,1.035)
            self.add_vertex(p,np.clip(col*var,0,1))
        for face in mesh.faces:
            self.f.append(tuple(offset+int(i) for i in face))

    def to_mesh(self):
        vertices=np.asarray(self.v,dtype=np.float32)
        faces=np.asarray(self.f,dtype=np.uint32)
        colors=np.clip(np.asarray(self.c)*255,0,255).astype(np.uint8)
        if len(vertices)==0 or len(faces)==0: raise ValueError('empty geometry: '+self.name)
        m=trimesh.Trimesh(vertices=vertices,faces=faces,vertex_colors=colors,process=False,validate=False)
        # Keep the material response soft and natural; vertex colour carries the authored variation.
        m.metadata['name']=self.name
        return m


def build_tree(levels=9, branches=7, detail='hero', seed=1033):
    rng=random.Random(seed)
    trunk=Builder('Spruce_Trunk_Bark')
    boughs=Builder('Spruce_Primary_Secondary_Boughs')
    needles=Builder('Spruce_Individual_Needles')
    snow=Builder('Spruce_Settled_Snow_Patches')
    height=8.65 if detail=='hero' else 8.25
    max_radius=3.32 if detail=='hero' else 3.08

    # Gently sweeping, tapered central leader with subtle bark grooves.
    trunk_pts=[]; trunk_r=[]
    for i in range(26):
        t=i/25
        trunk_pts.append([0.035*math.sin(t*3.2)+0.014*math.sin(t*9),height*t,0.028*math.sin(t*4.7)])
        trunk_r.append(.205*(1-t)**1.02+.007)
    trunk.add_tube(trunk_pts,trunk_r,'bark',14,seed+11,ridged=.13)
    # Six exposed root flares blend into the trunk and reach the forest floor.
    for k in range(6):
        a=k*math.tau/6+rng.uniform(-.16,.16)
        dx,dz=math.cos(a),math.sin(a)
        root_len=rng.uniform(.48,.72)
        root=[np.array([0,.14,0]),
              np.array([dx*root_len*.48,.025,dz*root_len*.48]),
              np.array([dx*root_len,-.098,dz*root_len])]
        trunk.add_tube(root,[.118,.061,.0075],'bark',8,seed+80+k,ridged=.10)

    whorl_data=[]
    for level in range(levels):
        t=level/max(1,levels-1)
        y=.68+t*(height-1.36)+rng.uniform(-.105,.105)
        spread=max(.075,max_radius*(1-t)**.79)
        count=branches+(1 if level%3==1 else 0)
        phase=level*2.399+seed*.11
        for b in range(count):
            branch_seed=seed*17+level*113+b*37
            local=random.Random(branch_seed)
            angle=phase+(b/count)*math.tau+local.uniform(-.25,.25)
            direction=np.array([math.cos(angle),0,math.sin(angle)])
            branch_len=spread*local.uniform(.82,1.14)
            # Strong lower boughs, progressively finer upper branches; asymmetric droop.
            droop=(.16+local.random()*.24)*(1-.28*t)+(.035+.030*local.random())*(1-.22*t)
            rise=local.uniform(.08,.21)*(1-t*.68)
            p0=np.array([0.,y,0.]) + direction*.055
            p1=p0+direction*branch_len*.33+np.array([0,rise-.008*(1-t),0])
            p2=p0+direction*branch_len*.69+np.array([0,rise*.40-.025-.020*(1-t),0])
            p3=p0+direction*branch_len+np.array([0,-droop,0])
            # A slight sideways sweep keeps whorls from looking like geometric wheels.
            lateral=np.array([-direction[2],0,direction[0]])
            p1+=lateral*local.uniform(-.05,.05)
            p2+=lateral*local.uniform(-.08,.08)
            p3+=lateral*local.uniform(-.08,.08)
            base_r=.058*(1-t*.66)*local.uniform(.85,1.12)
            # Gentle basal swelling gives the primary bough a more convincing
            # collar where it emerges from the trunk; the taper remains gradual.
            boughs.add_tube([p0,p1,p2,p3],
                            [base_r*1.28,base_r*.84,base_r*.39,.0065],
                            'twig',10,branch_seed,ridged=.022)
            whorl_data.append((p0,p1,p2,p3,direction,lateral,branch_seed,t,branch_len,base_r))

            # Dense, overlapping needle rosettes follow the full length of each main bough.
            # The spacing is deliberately shorter than the needle length so each branch
            # reads as a continuous, naturally irregular evergreen spray rather than a
            # visible bare stick with a handful of tufts.
            twig_dir=unit(p3-p0 + np.array([0,.045,0]))
            branch_distance=float(np.linalg.norm(p3-p0))
            spacing=.072 if detail=='hero' else .145
            station_count=max(5,int(branch_distance/spacing))
            for s in range(station_count):
                along=.10+.87*(s/max(1,station_count-1))
                center=p0+(p3-p0)*along
                needles.add_spray(center,twig_dir,13 if detail=='hero' else 10,
                                  .102 if t<.78 else .076,
                                  branch_seed+100+s,scale=1.0-t*.22)

            # A finer upper-facing spray layer builds the soft, dense silhouette seen
            # in the close-up reference, without introducing opaque low-poly foliage blobs.
            if detail=='hero' or level%2==0:
                fine_spacing=.12 if detail=='hero' else .22
                fine_count=max(3,int(branch_distance/fine_spacing))
                lateral_axis=unit(np.cross(twig_dir,np.array([0.,1.,0.])))
                for s in range(fine_count):
                    along=.16+.76*(s/max(1,fine_count-1))
                    center=p0+(p3-p0)*along + np.array([0,.018,0])
                    diagonal=unit(twig_dir*.62 + np.array([0,.52,0]))
                    needles.add_spray(center,diagonal,9 if detail=='hero' else 7,
                                      .088 if t<.78 else .066,
                                      branch_seed+1600+s,scale=1.0-t*.24)

            # Three tiers of asymmetrical secondary twigs fork from each primary bough.
            attach_points=[.30,.53,.76] if detail=='hero' else [.30,.52,.74]
            for j,at in enumerate(attach_points):
                root=p0+(p3-p0)*at
                fork_count=2
                for side_sign in ([-1,1] if fork_count==2 else [1]):
                    side_dir=unit(direction*.44+lateral*side_sign*.72+np.array([0,.15,0]))
                    fork_len=branch_len*local.uniform(.145,.225)*(1-.28*t)
                    mid=root+side_dir*fork_len*.52+np.array([0,.045,0])
                    tip=root+side_dir*fork_len+np.array([0,-fork_len*local.uniform(.09,.24)-.012*(1-t),0])
                    # A fine secondary branch with a forked pair of tertiary tips.
                    r0=base_r*.43
                    boughs.add_tube([root,mid,tip],[r0,r0*.49,.0035],'twig',6,branch_seed+200+j*11+(1 if side_sign>0 else 0),ridged=.035)
                    # One connected snow mantle follows each secondary twig.
                    # Fewer, longer deposits avoid the repeated placed-cap look.
                    if local.random() < .82:
                        snow.add_snow_ribbon([root,mid,tip],
                            half_width=local.uniform(.038,.047)*(1-.20*t),
                            thickness=local.uniform(.018,.024)*(1-.12*t),
                            lift=.035*(1-.12*t),
                            seed=branch_seed+4200+j*29+side_sign*7,
                            segments=20,start=.045,end=.975,support_radii=[r0,r0*.49,.0035])
                    secondary_positions=(.14,.34,.54,.74,.92)
                    for s,frac in enumerate(secondary_positions):
                        c=root+(tip-root)*frac
                        d=unit(tip-root)
                        needles.add_spray(c,d,9 if detail=='hero' else 8,.078 if t<.8 else .059,branch_seed+300+j*19+s*5+side_sign,scale=1.0-t*.22)
                    if detail=='hero':
                        # Terminal forklets add the fine silhouette visible in the branch reference.
                        for fsign in (-1,1):
                            fork_root=root+(tip-root)*.60
                            fd=unit(side_dir*.45+lateral*fsign*.76+np.array([0,.20,0]))
                            fl=fork_len*local.uniform(.25,.38)
                            fm=fork_root+fd*fl*.54
                            ft=fork_root+fd*fl+np.array([0,-.035,0])
                            boughs.add_tube([fork_root,fm,ft],[.010,.005,.0018],'twig',5,branch_seed+500+j*23+fsign,ridged=.02)
                            if local.random() < .34:
                                snow.add_snow_ribbon([fork_root,fm,ft],
                                    half_width=.015*(1-.20*t), thickness=.0085,
                                    lift=.016, seed=branch_seed+5100+j*31,
                                    segments=12, start=.14, end=.96,support_radii=[.010,.005,.0018])
                            needles.add_spray(fm,fd,5,.055,branch_seed+600+j*29+fsign,scale=1.0-t*.18)
                            needles.add_spray(ft,fd,5,.050,branch_seed+700+j*31+fsign,scale=1.0-t*.18)

            # Dense foliage clumps bridge the spaces between individual twigs.
            # The clumps are made of separate needles distributed through a soft
            # ellipsoid, so there is no opaque cone or low-poly foliage blob.
            cluster_spacing=.095 if detail=='hero' else .165
            cluster_stations=max(6,int(branch_distance/cluster_spacing))
            for ci in range(cluster_stations):
                along=.08+.90*(ci/max(1,cluster_stations-1))
                cc=p0+(p3-p0)*along
                taper=(1.0-t*.46)
                needles.add_foliage_cluster(cc,twig_dir,lateral,
                    64 if detail=='hero' else 52,branch_seed+2600+ci,
                    scale=taper,length=.105 if t<.78 else .080)

            # Broad, overlapping branchlet fans fill the crown between whorls.
            # Five directions around every major bough build a real 3D canopy:
            # two lateral curtains, an upper fan, and two lightly drooping fans.
            shoot_spacing=.19 if detail=='hero' else .36
            shoot_stations=max(5,int(branch_distance/shoot_spacing))
            up_axis=np.array([0.,1.,0.])
            shoot_directions=(
                unit(direction*.46+lateral*.80+up_axis*.42),
                unit(direction*.46-lateral*.80+up_axis*.42),
                unit(direction*.58+up_axis*.82),
                unit(direction*.58+lateral*.24-up_axis*.74),
                unit(direction*.58-lateral*.24-up_axis*.74),
            )
            for si in range(shoot_stations):
                along=.13+.84*(si/max(1,shoot_stations-1))
                root=p0+(p3-p0)*along
                for di,shoot_dir in enumerate(shoot_directions):
                    jitter=local.uniform(-.045,.045)
                    sd=unit(shoot_dir+lateral*jitter)
                    shoot_len=local.uniform(.38,.55 if detail=='hero' else .45)*(1-.35*t)
                    smid=root+sd*shoot_len*.50+up_axis*.018
                    stip=root+sd*shoot_len+np.array([0,-shoot_len*.065,0])
                    r0=base_r*.34
                    boughs.add_tube([root,smid,stip],[r0,r0*.42,.0015],'twig',6,
                                    branch_seed+1800+si*11+di,ridged=.045)
                    if di in (0,1,2) and local.random() < .76:
                        # A single, feather-edged mantle runs along the whole fan.
                        snow.add_snow_ribbon([root,smid,stip],
                            half_width=local.uniform(.041,.052)*(1-.20*t),
                            thickness=local.uniform(.018,.024),
                            lift=.030, seed=branch_seed+5300+si*13+di*3,
                            segments=20,start=.055,end=.965,support_radii=[r0,r0*.42,.0015])
                    shoot_axis=unit(stip-root)
                    for ni,frac in enumerate((.18,.52,.86)):
                        c=root+(stip-root)*frac
                        needles.add_spray(c,shoot_axis,11 if detail=='hero' else 7,
                                          .092 if t<.78 else .068,
                                          branch_seed+1900+si*41+di*7+ni,scale=1.0-t*.18)

            # One long, naturally irregular mantle follows the primary bough.
            # It tapers only near the branch base and tip; it is not split into
            # repeated short caps, so the snow reads as a connected drift.
            snow_chance=.96 if detail=='hero' else .90
            if local.random()<snow_chance:
                snow.add_snow_ribbon([p0,p1,p2,p3],
                    half_width=local.uniform(.062,.076)*(1-t*.28),
                    thickness=local.uniform(.034,.043)*(1-t*.14),
                    lift=local.uniform(.056,.070)*(1-t*.12),
                    seed=branch_seed+800,segments=34,start=.015,end=.99,support_radii=[base_r*1.28,base_r*.84,base_r*.39,.0065])

    # A broken, slender crown leader continues slightly above the top whorl.
    leader=[np.array([.035, height*.89, .028]),np.array([.028,height*.95,.01]),np.array([.012,height,0]),np.array([.004,height+.14,-.006])]
    trunk.add_tube(leader,[.035,.023,.010,.0015],'twig',7,seed+999,ridged=.035)
    parts={'trunk':trunk.to_mesh(),'branches':boughs.to_mesh(),'snow':snow.to_mesh()}
    if needles.v and needles.f: parts['needles']=needles.to_mesh()
    return parts, whorl_data


def build_bough(seed=131):
    rng=random.Random(seed)
    wood=Builder('Spruce_Bough_Wood')
    needle=Builder('Spruce_Bough_Needles')
    snow=Builder('Spruce_Bough_Settled_Snow')
    # A mature, gently bowed bough with paired forked lateral sprays.
    pts=[np.array([0.,0.,0.]),np.array([.62,.14,.04]),np.array([1.35,.12,.10]),np.array([2.0,-.18,.08])]
    wood.add_tube(pts,[.062,.048,.029,.010],'twig',9,seed,ridged=.035)
    lateral=np.array([0.,0.,1.])
    for j,at in enumerate(np.linspace(.10,.92,11)):
        root=pts[0]+(pts[-1]-pts[0])*float(at)
        dirs=(unit(np.array([.56,.36,.74])),unit(np.array([.56,.36,-.74])),unit(np.array([.62,.82,.08])))
        for di,d in enumerate(dirs):
            length=rng.uniform(.28,.42)
            mid=root+d*length*.52+np.array([0,.025,0])
            tip=root+d*length+np.array([0,-.015,0])
            wood.add_tube([root,mid,tip],[.018,.008,.0018],'twig',6,seed+j*31+di,ridged=.04)
            if di in (0,2):
                snow.add_snow_ribbon([root,mid,tip],.044,.024,.038,
                    seed+2500+j*17+di,segments=8,start=.12,end=.92,support_radii=[.018,.008,.0018])
            for f,frac in enumerate((.14,.34,.54,.74,.92)):
                c=root+(tip-root)*frac
                needle.add_spray(c,d,9,.066,seed+j*100+di*13+f*5,scale=1.0)
            fork_root=root+(tip-root)*.68
            for side in (-1,1):
                fd=unit(d*.48+np.array([0,.35,side*.68]))
                fl=length*.34
                fm=fork_root+fd*fl*.5; ft=fork_root+fd*fl
                wood.add_tube([fork_root,fm,ft],[.0045,.002,.0007],'twig',5,seed+j*71+di*17+side,ridged=.02)
                if side in (-1,1) and di in (0,2) and rng.random()<.34:
                    snow.add_snow_ribbon([fork_root,fm,ft],.014,.0085,.016,
                        seed+2700+j*19+di*11,segments=10,start=.14,end=.96,support_radii=[.0045,.002,.0007])
                for f,frac in enumerate((.28,.72)):
                    needle.add_spray(fork_root+(ft-fork_root)*frac,fd,6,.052,seed+j*91+di*19+side*7+f)
    main_axis=unit(pts[-1]-pts[0]); main_lateral=np.array([0.,0.,1.])
    for k,frac in enumerate(np.linspace(.025,.975,34)):
        c=pts[0]+(pts[-1]-pts[0])*float(frac)+np.array([0,.015,0])
        needle.add_foliage_cluster(c,main_axis,main_lateral,105,seed+1400+k,scale=.92,length=.079)
    # A single connected snow mantle follows the full main bough.
    # The irregular feathered margins leave needles visible at the sides.
    snow.add_snow_ribbon(pts,.066,.039,.064,seed+800,
                         segments=36,start=.015,end=.99,support_radii=[.062,.048,.029,.010])
    parts={'wood':wood.to_mesh(),'snow':snow.to_mesh()}
    if needle.v and needle.f: parts['needles']=needle.to_mesh()
    return parts


def scene_for(parts, name):
    scene=trimesh.Scene()
    for part,mesh in parts.items():
        # Keep COLOR_0 vertex colours in the exported glTF meshes. Assigning a
        # separate TextureVisuals material here would replace the ColorVisuals.
        scene.add_geometry(mesh,geom_name=mesh.metadata['name'],node_name=mesh.metadata['name'])
    scene.metadata['asset_name']=name
    return scene


def pack_game_binary(parts, filename):
    # Pack the browser LOD as one gzip stream so static hosting serves roughly
    # half the bytes of two separate Base64 Float32/Uint32 arrays.
    merged=trimesh.util.concatenate(list(parts.values()))
    vertices=merged.vertices.astype('<f4')
    normals=merged.vertex_normals.astype('<f4')
    colors=merged.visual.vertex_colors[:,:3].astype(np.float32)/255.0
    data=np.column_stack([vertices,normals,colors]).astype('<f4')
    indices=merged.faces.astype('<u4')
    vertex_bytes=data.tobytes()
    index_bytes=indices.tobytes()
    raw=vertex_bytes+index_bytes
    compressed=gzip.compress(raw,compresslevel=6,mtime=0)
    Path(filename).write_bytes(compressed)
    metadata={
        'vertexCount':len(data),
        'indexCount':len(indices)*3,
        'vertexByteLength':len(vertex_bytes),
        'uncompressedByteLength':len(raw),
    }
    meta_path=Path(filename).with_name('hero_spruce_mesh_meta.js')
    meta_path.write_text("/* Winter World spruce V52 game LOD metadata. */\nwindow.WinterWorldSpruceMeta="+json.dumps(metadata,separators=(',',':'))+";\n",encoding='utf-8')
    return len(data),len(indices)*3,len(compressed),len(raw)



def main():
    # V52 rebuilds branch structure and snow from source parameters, but reuses
    # V47's individually modeled needle mesh to avoid regenerating nearly a million
    # needle primitives. A small deterministic sag/color pass keeps it aligned with
    # the slightly more snow-loaded V52 branches while preserving the approved shape.
    base_dir=Path(os.environ.get('WINTERWORLD_V47_BASE', str(OUT/'Base_V47')))
    tree_base=base_dir/'Hero_Spruce_V47_GameLOD.glb'
    bough_base=base_dir/'Hero_Spruce_V47_Bough.glb'
    if not tree_base.is_file() or not bough_base.is_file():
        raise FileNotFoundError('V48/V47 source meshes are required. Place Hero_Spruce_V47_GameLOD.glb and Hero_Spruce_V47_Bough.glb in ./Base_V47 or set WINTERWORLD_V47_BASE.')
    old_tree=trimesh.load(tree_base,force='scene')
    old_bough=trimesh.load(bough_base,force='scene')
    tree_needles=old_tree.geometry['Spruce_Individual_Needles'].copy()
    bough_needles=old_bough.geometry['Spruce_Bough_Needles'].copy()

    # Skip fresh needle generation; reuse the approved individual meshes above.
    original_spray=Builder.add_spray
    original_cluster=Builder.add_foliage_cluster
    Builder.add_spray=lambda self,*args,**kwargs: None
    Builder.add_foliage_cluster=lambda self,*args,**kwargs: None
    try:
        lod_parts,_=build_tree(levels=15,branches=8,detail='lod',seed=1235)
        bough_parts=build_bough()
    finally:
        Builder.add_spray=original_spray
        Builder.add_foliage_cluster=original_cluster

    # Tiny snow-load response: lower outer branchlets sag a few centimetres.
    vv=tree_needles.vertices.copy()
    radius=np.sqrt(vv[:,0]**2+vv[:,2]**2)
    low=np.clip((8.65-vv[:,1])/8.65,0.0,1.0)
    radial=np.clip(radius/3.35,0.0,1.0)
    vv[:,1]-=.040*(radial**1.55)*low
    tree_needles.vertices=vv
    # Natural needle hue variation: retain V47's green palette, add restrained
    # cool shadow/young-tip variation without changing the branch silhouette.
    rgba=tree_needles.visual.vertex_colors.copy()
    if rgba.shape[1] == 4:
        rgb=rgba[:,:3].astype(np.float32)
        modulation=(np.sin(vv[:,0]*13.7+vv[:,2]*9.1+vv[:,1]*4.3)*.018
                    +np.sin(vv[:,0]*4.7-vv[:,2]*11.3)*.012)
        rgb[:,0]*=(.985+modulation*.35)
        rgb[:,1]*=(1.0+modulation)
        rgb[:,2]*=(.99+modulation*.50)
        rgba[:,:3]=np.clip(rgb,0,255).astype(np.uint8)
        tree_needles.visual.vertex_colors=rgba
    lod_parts['needles']=tree_needles
    bough_parts['needles']=bough_needles

    scene_for(lod_parts,'Hero Spruce V52 Game LOD').export(OUT/'Hero_Spruce_V52_GameLOD.glb')
    scene_for(bough_parts,'Spruce Bough V52 Detail Asset').export(OUT/'Hero_Spruce_V52_Bough.glb')
    vcount=0; icount=0; compressed_bytes=0; uncompressed_bytes=0
    stats={}
    for label,parts in [('game_lod',lod_parts),('bough',bough_parts)]:
        stats[label]={k:{'vertices':len(v.vertices),'triangles':len(v.faces)} for k,v in parts.items()}
        stats[label]['total_vertices']=sum(len(v.vertices) for v in parts.values())
        stats[label]['total_triangles']=sum(len(v.faces) for v in parts.values())
    stats['game_binary']={'status':'not generated in this pass; GLB is the validated source asset'}
    stats['dimensions_m']={'game_lod_height':8.42,'game_lod_width':6.88,'game_lod_depth':6.80}
    stats['notes']='V52 snow-contact polish: every primary, secondary, tertiary and standalone-bough snow mantle follows the local supporting wood radius and overlaps it slightly at the lower edge. The overlap is clamped against local branch thickness and tip micro-relief so tapered branches cannot reveal floating seams. The approved crown silhouette, snow coverage, needle distribution and procedural random sequence are preserved.'
    stats['verification']='GLBs reloaded and structurally checked with trimesh. Preview renders use a software renderer; Blender/Cycles and in-game runtime rendering have not been performed.'
    (OUT/'Hero_Spruce_V52_Stats.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
    make_blender_setup()
    print(json.dumps(stats,indent=2))
    for q in sorted(OUT.iterdir()):
        if q.is_file(): print(q.name,q.stat().st_size)


def make_blender_setup():
    script=r'''# Blender 4.x setup for Hero Spruce V52. Run from Blender's Scripting workspace.
import bpy, os, math
from mathutils import Vector
HERE=os.path.dirname(os.path.abspath(__file__))
GLB=os.path.join(HERE,"Hero_Spruce_V52_GameLOD.glb")
BLEND=os.path.join(HERE,"Hero_Spruce_V52.blend")
RENDER=os.path.join(HERE,"Hero_Spruce_V52_ThreeQuarter.png")
for obj in list(bpy.data.objects): bpy.data.objects.remove(obj,do_unlink=True)
bpy.ops.import_scene.gltf(filepath=GLB)
root=bpy.data.objects.new("HERO SPRUCE V52 | ROOT",None); bpy.context.scene.collection.objects.link(root)
def make_pbr_material(name, attr_name, roughness, noise_scale, bump_strength, bump_distance, subsurface=0.0):
    mat=bpy.data.materials.new(name); mat.use_nodes=True
    nodes=mat.node_tree.nodes; links=mat.node_tree.links; nodes.clear()
    out=nodes.new('ShaderNodeOutputMaterial'); out.location=(650,40)
    bs=nodes.new('ShaderNodeBsdfPrincipled'); bs.location=(380,40)
    bs.inputs['Roughness'].default_value=roughness
    sub=bs.inputs.get('Subsurface Weight') or bs.inputs.get('Subsurface')
    if sub is not None: sub.default_value=subsurface
    vc=nodes.new('ShaderNodeVertexColor'); vc.layer_name=attr_name; vc.location=(-420,160)
    noise=nodes.new('ShaderNodeTexNoise'); noise.location=(-420,-140)
    noise.inputs['Scale'].default_value=noise_scale
    noise.inputs['Detail'].default_value=4.0
    noise.inputs['Roughness'].default_value=.72
    bump=nodes.new('ShaderNodeBump'); bump.location=(120,-100)
    bump.inputs['Strength'].default_value=bump_strength
    bump.inputs['Distance'].default_value=bump_distance
    links.new(vc.outputs['Color'],bs.inputs['Base Color'])
    links.new(noise.outputs['Fac'],bump.inputs['Height'])
    links.new(bump.outputs['Normal'],bs.inputs['Normal'])
    links.new(bs.outputs['BSDF'],out.inputs['Surface'])
    return mat

for obj in list(bpy.context.scene.objects):
    if obj.type=='MESH':
        obj.parent=root
        for p in obj.data.polygons: p.use_smooth=True
        attr=obj.data.color_attributes.active_color if hasattr(obj.data,'color_attributes') else None
        attr_name=attr.name if attr else 'Color'
        low=obj.name.lower()
        if 'snow' in low:
            mat=make_pbr_material('Snow | fine granular powder',attr_name,.84,92.0,.16,.007,.035)
        elif 'needle' in low:
            mat=make_pbr_material('Spruce needles | waxy blue-green',attr_name,.72,135.0,.10,.003,.015)
        else:
            mat=make_pbr_material('Spruce bark | ridged warm brown',attr_name,.90,32.0,.28,.022,0.0)
        obj.data.materials.clear(); obj.data.materials.append(mat)
# Studio floor and a deep winter dusk world.
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,-.06,0)); floor=bpy.context.object; floor.name="Snow studio floor"
mat=bpy.data.materials.new("Soft blue-white snow ground"); mat.diffuse_color=(.62,.73,.82,1); mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=(.62,.73,.82,1); bs.inputs['Roughness'].default_value=.88; floor.data.materials.append(mat)
world=bpy.data.worlds.new("Winter dusk studio") if bpy.data.worlds.get("Winter dusk studio") is None else bpy.data.worlds["Winter dusk studio"]
bpy.context.scene.world=world; world.use_nodes=True; world.node_tree.nodes['Background'].inputs['Color'].default_value=(.025,.045,.075,1); world.node_tree.nodes['Background'].inputs['Strength'].default_value=.30
scene=bpy.context.scene
# Large soft sources make the needles readable without washing out their deep green.
def area(name,loc,power,color,size,target=(0,4.1,0)):
    d=bpy.data.lights.new(name,'AREA'); d.energy=power; d.color=color; d.shape='DISK'; d.size=size
    o=bpy.data.objects.new(name,d); scene.collection.objects.link(o); o.location=loc; o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
area('Warm soft key',(5,-7,8),2400,(1.0,.88,.77),7)
area('Cool sky fill',(-6,1,6),2100,(.72,.84,1.0),8)
area('Snow rim',(2,7,-5),2800,(.79,.88,1.0),5)
camd=bpy.data.cameras.new('Spruce portrait camera'); cam=bpy.data.objects.new('Spruce portrait camera',camd); scene.collection.objects.link(cam)
cam.location=(10,6,13); target=Vector((0,4.2,0)); cam.rotation_euler=(target-Vector(cam.location)).to_track_quat('-Z','Y').to_euler(); camd.lens=58; scene.camera=cam
scene.render.engine='CYCLES'; scene.cycles.samples=96; scene.cycles.use_denoising=True; scene.cycles.use_adaptive_sampling=True
scene.render.resolution_x=1800; scene.render.resolution_y=2000; scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'; scene.render.filepath=RENDER; scene.view_settings.view_transform='AgX'
try: scene.view_settings.look='AgX - Medium High Contrast'
except Exception: pass
scene.render.film_transparent=False
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
bpy.ops.render.render(write_still=True)
print("Saved",BLEND,"and",RENDER)
'''
    (OUT/'Hero_Spruce_V52_Blender_Setup.py').write_text(script,encoding='utf-8')

if __name__=='__main__': main()
