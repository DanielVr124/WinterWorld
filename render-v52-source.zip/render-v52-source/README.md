# Winter World V52 Cycles render job

This job reproducibly rebuilds the V52 source geometry from the V47 and V52 Python mesh generators, then imports the exported GLBs in Blender and renders the hero tree and close-up bough using the real Cycles CPU renderer.

The job runs in GitHub Actions on a separate `render-v52-cycles` branch. It does not deploy or modify the public GitHub Pages site.
