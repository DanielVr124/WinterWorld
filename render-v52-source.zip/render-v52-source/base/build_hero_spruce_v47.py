#!/usr/bin/env python3
"""Generate a realistic, snow-laden Norway spruce for Winter World.

Outputs:
  Hero_Spruce_V47_GameLOD.glb       high-detail hero tree
  Hero_Spruce_V47_GameLOD.glb    optimized reusable forest mesh
  Hero_Spruce_V47_Bough.glb      close-up reusable evergreen bough
  hero_spruce_mesh_data.js       compact browser mesh data for the game LOD
  Hero_Spruce_V47_Blender_Setup.py Blender import / scene / render script

Requires Python 3, numpy, trimesh. All dimensions are meters, Y up.
"""
from __future__ import annotations
import base64, gzip, json, math, os, random, struct
from pathlib import Path
import numpy as np
import trimesh

OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)

PALETTE = {
    'bark': np.array([[0.105,0.070,0.050],[0.16,0.100,0.067],[0.205,0.132,0.085],[0.075,0.060,0.047]], dtype=float),
    'twig': np.array([[0.13,0.085,0.058],[0.19,0.125,0.080],[0.25,0.165,0.105]], dtype=float),
    'needle': np.array([[0.032,0.155,0.102],[0.046,0.215,0.142],[0.068,0.275,0.181],[0.098,0.345,0.222],[0.145,0.425,0.275]], dtype=float),
    'snow': np.array([[0.83,0.89,0.95],[0.91,0.94,0.98],[0.74,0.83,0.91],[0.97,0.98,1.0]], dtype=float),
}


def unit(v):
    v = np.asarray(v, dtype=float)
    n = np.linalg.norm(v)
    return v / (n if n > 1e-10 else 1.0)


def frame_from_axis(axis):
    axis = unit(axis)
    ref = np.array([0.,1.,0.]) if abs(axis[1]) < 0.92 else np.array([1.,0.,0.])
    u = unit(np.cross(axis, ref))
    v = unit(np.cross(axis, u))
    return u, v, axis


class Builder:
    def __init__(self, name):
        self.name = name
        self.v = []
        self.f = []
        self.c = []

    def add_vertex(self, p, c):
        self.v.append(np.asarray(p, dtype=np.float32))
        self.c.append(np.asarray(c, dtype=np.float32))

    def add_tube(self, points, radii, color='twig', sides=7, seed=0, ridged=0.0):
        points = [np.asarray(p, dtype=float) for p in points]
        radii = list(radii)
        first = len(self.v)
        rng = random.Random(seed)
        rings = []
        for i, (p, radius) in enumerate(zip(points, radii)):
            if i == 0: tangent = unit(points[1]-points[0])
            elif i == len(points)-1: tangent = unit(points[-1]-points[-2])
            else: tangent = unit(points[i+1]-points[i-1])
            u, vv, _ = frame_from_axis(tangent)
            ring=[]
            for j in range(sides):
                a=2*math.pi*j/sides
                wave = 1.0 + ridged*(0.52*math.sin(a*5+seed*.37)+0.22*math.sin(a*11-seed*.21))
                rr=max(0.0008, radius*wave)
                q=p+rr*(math.cos(a)*u+math.sin(a)*vv)
                base = PALETTE[color][(i+j+seed)%len(PALETTE[color])].copy()
                var = 0.88 + 0.22*rng.random()
                self.add_vertex(q, np.clip(base*var,0,1))
                ring.append(len(self.v)-1)
            rings.append(ring)
        for i in range(len(rings)-1):
            for j in range(sides):
                a=rings[i][j]; b=rings[i][(j+1)%sides]
                c=rings[i+1][j]; d=rings[i+1][(j+1)%sides]
                self.f.extend([(a,b,c),(b,d,c)])
        # Triangulated end caps prevent open tips on thick branches.
        for j in range(1, sides-1):
            self.f.append((rings[0][0], rings[0][j+1], rings[0][j]))
            self.f.append((rings[-1][0], rings[-1][j], rings[-1][j+1]))

    def add_needle(self, start, direction, length, width, color_idx, seed=0):
        rng=random.Random(seed)
        d=unit(direction)
        u,v,_=frame_from_axis(d)
        twist=rng.random()*math.pi*2
        uu=math.cos(twist)*u+math.sin(twist)*v
        vv=-math.sin(twist)*u+math.cos(twist)*v
        w=width
        h=width*0.36
        base=np.asarray(start,dtype=float)
        # A slender four-sided spruce needle, tapering to a sharp tip.
        ring=[base+uu*w+vv*h, base-uu*w+vv*h, base-uu*w-vv*h, base+uu*w-vv*h]
        tip=base+d*length
        ci=PALETTE['needle'][color_idx % len(PALETTE['needle'])]
        ci2=np.clip(ci*1.18+np.array([.012,.018,.008]),0,1)
        first=len(self.v)
        for p in ring: self.add_vertex(p,ci)
        self.add_vertex(tip,ci2)
        self.f.extend([(first,first+1,first+4),(first+1,first+2,first+4),
                       (first+2,first+3,first+4),(first+3,first,first+4),
                       (first+3,first+2,first+1),(first+3,first+1,first)])

    def add_spray(self, center, axis, count, length, seed, scale=1.0):
        # Vectorized needle rosette: preserves individual tapered needles while
        # avoiding one Python object/method call per leaf.
        rng=np.random.default_rng(seed)
        axis=unit(axis); u,v,_=frame_from_axis(axis)
        phase=rng.random()*math.tau
        angles=phase+np.arange(count)*math.tau/count+rng.uniform(-.18,.18,count)
        radial=np.cos(angles)[:,None]*u[None,:]+np.sin(angles)[:,None]*v[None,:]
        axial=rng.uniform(.19,.39,count)[:,None]
        dirs=radial*rng.uniform(.78,1.05,(count,1))+axis[None,:]*axial
        dirs+=np.column_stack([np.zeros(count),rng.uniform(-.12,.20,count),np.zeros(count)])
        dirs/=np.maximum(np.linalg.norm(dirs,axis=1,keepdims=True),1e-10)
        refs=np.tile(np.array([0.,1.,0.]),(count,1))
        refs[np.abs(dirs[:,1])>=.92]=np.array([1.,0.,0.])
        uu=np.cross(dirs,refs); uu/=np.maximum(np.linalg.norm(uu,axis=1,keepdims=True),1e-10)
        vv=np.cross(dirs,uu)
        twists=rng.random(count)*math.pi*2
        u2=np.cos(twists)[:,None]*uu+np.sin(twists)[:,None]*vv
        v2=-np.sin(twists)[:,None]*uu+np.cos(twists)[:,None]*vv
        offsets=radial*rng.uniform(.004,.018,(count,1))*scale
        bases=np.asarray(center,dtype=float)[None,:]+offsets
        lens=length*rng.uniform(.76,1.24,count)*scale
        widths=lens*rng.uniform(.035,.055,count)
        heights=widths*.36
        verts=np.empty((count,5,3),dtype=np.float32)
        verts[:,0]=bases+u2*widths[:,None]+v2*heights[:,None]
        verts[:,1]=bases-u2*widths[:,None]+v2*heights[:,None]
        verts[:,2]=bases-u2*widths[:,None]-v2*heights[:,None]
        verts[:,3]=bases+u2*widths[:,None]-v2*heights[:,None]
        verts[:,4]=bases+dirs*lens[:,None]
        palette=PALETTE['needle']
        color_idx=rng.integers(0,len(palette),count)
        colors=palette[color_idx]
        colors2=np.clip(colors*1.18+np.array([.012,.018,.008]),0,1)
        cols=np.empty((count,5,3),dtype=np.float32)
        cols[:,:4]=colors[:,None,:]; cols[:,4]=colors2
        base=len(self.v)
        self.v.extend(verts.reshape((-1,3)))
        self.c.extend(cols.reshape((-1,3)))
        offsets_i=base+np.arange(count,dtype=np.uint32)*5
        local_faces=np.array([[0,1,4],[1,2,4],[2,3,4],[3,0,4],[3,2,1],[3,1,0]],dtype=np.uint32)
        faces=(offsets_i[:,None,None]+local_faces[None,:,:]).reshape((-1,3))
        self.f.extend(faces)

    def add_foliage_cluster(self, center, axis, lateral, count, seed, scale=1.0, length=.085):
        # A compact 3D cloud of individually modeled needles. Starts are scattered
        # through the bough volume, not all pinned to one point like a starburst.
        rng=np.random.default_rng(seed)
        axis=unit(axis); lateral=unit(lateral); up=np.array([0.,1.,0.])
        side_extent=.22*scale; up_extent=.25*scale; axial_extent=.13*scale
        bases=np.asarray(center,dtype=float)[None,:]
        bases=bases + axis[None,:]*rng.uniform(-axial_extent,axial_extent,(count,1))
        bases=bases + lateral[None,:]*rng.uniform(-side_extent,side_extent,(count,1))
        bases=bases + up[None,:]*rng.uniform(-up_extent,up_extent,(count,1))
        dirs=axis[None,:]*rng.uniform(.52,.88,(count,1))
        dirs+=lateral[None,:]*rng.uniform(-.62,.62,(count,1))
        dirs+=up[None,:]*rng.uniform(-.38,.72,(count,1))
        dirs/=np.maximum(np.linalg.norm(dirs,axis=1,keepdims=True),1e-10)
        refs=np.tile(up,(count,1)); refs[np.abs(dirs[:,1])>=.92]=np.array([1.,0.,0.])
        uu=np.cross(dirs,refs); uu/=np.maximum(np.linalg.norm(uu,axis=1,keepdims=True),1e-10)
        vv=np.cross(dirs,uu)
        twist=rng.random(count)*math.tau
        u2=np.cos(twist)[:,None]*uu+np.sin(twist)[:,None]*vv
        v2=-np.sin(twist)[:,None]*uu+np.cos(twist)[:,None]*vv
        lens=length*scale*rng.uniform(.70,1.32,count)
        widths=lens*rng.uniform(.035,.055,count); heights=widths*.36
        verts=np.empty((count,5,3),dtype=np.float32)
        verts[:,0]=bases+u2*widths[:,None]+v2*heights[:,None]
        verts[:,1]=bases-u2*widths[:,None]+v2*heights[:,None]
        verts[:,2]=bases-u2*widths[:,None]-v2*heights[:,None]
        verts[:,3]=bases+u2*widths[:,None]-v2*heights[:,None]
        verts[:,4]=bases+dirs*lens[:,None]
        palette=PALETTE['needle']; ci=rng.integers(0,len(palette),count)
        colors=palette[ci]; bright=np.clip(colors*1.16+np.array([.010,.016,.008]),0,1)
        cols=np.empty((count,5,3),dtype=np.float32); cols[:,:4]=colors[:,None,:]; cols[:,4]=bright
        base=len(self.v); self.v.extend(verts.reshape((-1,3))); self.c.extend(cols.reshape((-1,3)))
        offsets=base+np.arange(count,dtype=np.uint32)*5
        faces=(offsets[:,None,None]+np.array([[0,1,4],[1,2,4],[2,3,4],[3,0,4],[3,2,1],[3,1,0]],dtype=np.uint32)[None,:,:]).reshape((-1,3))
        self.f.extend(faces)

    def add_snow_ribbon(self, points, half_width, thickness, lift, seed,
                        segments=16, start=0.0, end=1.0):
        """A thin, tapered snow mantle that conforms to a twig/bough centerline.

        Unlike the earlier detached ellipsoid clumps, this is a shallow strip
        built from a longitudinal sample of the branch. Its cross section is a
        convex cap with feathered edges; it cannot droop below the branch line.
        """
        pts=[np.asarray(p,dtype=float) for p in points]
        if len(pts)<2 or end<=start: return
        rng=np.random.default_rng(seed)
        lengths=np.array([np.linalg.norm(pts[i+1]-pts[i]) for i in range(len(pts)-1)])
        cumulative=np.concatenate([[0.0],np.cumsum(lengths)])
        total=float(cumulative[-1])
        if total<1e-5: return
        cross=np.linspace(-1.0,1.0,13,dtype=float)
        crown=np.sqrt(np.maximum(0.0,1.0-cross*cross))**.62
        verts=[]; cols=[]
        snow_palette=PALETTE['snow']
        base_color=snow_palette[int(rng.integers(0,len(snow_palette)))]
        phase=float(rng.uniform(0,math.tau))
        # Broken, gently wavy edges resemble settled powder caught by needles.
        for i in range(segments+1):
            u=i/segments
            path_u=start+(end-start)*u
            dist=path_u*total
            seg=min(len(pts)-2,max(0,int(np.searchsorted(cumulative,dist,side='right')-1)))
            seg_len=max(1e-8,lengths[seg])
            f=np.clip((dist-cumulative[seg])/seg_len,0.0,1.0)
            center=pts[seg]*(1-f)+pts[seg+1]*f
            # Tangent from the local branch curve, not a single global direction.
            lo=max(0.0,dist-total*.012); hi=min(total,dist+total*.012)
            def at_distance(d):
                k=min(len(pts)-2,max(0,int(np.searchsorted(cumulative,d,side='right')-1)))
                ff=np.clip((d-cumulative[k])/max(1e-8,lengths[k]),0.0,1.0)
                return pts[k]*(1-ff)+pts[k+1]*ff
            tangent=unit(at_distance(hi)-at_distance(lo))
            up=np.array([0.,1.,0.])
            side=unit(np.cross(up,tangent))
            if np.linalg.norm(side)<.15:
                side=unit(np.cross(np.array([0.,0.,1.]),tangent))
            if np.linalg.norm(side)<.15: side=np.array([1.,0.,0.])
            # More snow can settle on flatter branch sections; steep sections taper.
            flatness=1.0-min(.48,abs(float(tangent[1]))*.62)
            longitudinal=np.sin(np.pi*u)**.28
            edge_wave=(.86+.095*np.sin(u*math.tau*3+phase)+.065*np.sin(u*math.tau*7-phase*.7)+float(rng.uniform(-.045,.045)))
            width=half_width*longitudinal*edge_wave*flatness
            # The mantle sits on the upper side of the foliage, then follows its slope.
            waviness=(.0048*np.sin(u*math.tau*3.2+phase)+.0030*np.sin(u*math.tau*8.1+phase*.4)+float(rng.uniform(-.0015,.0015)))
            base_y=center[1]+lift+waviness
            local_thickness=thickness*(.82+.18*np.sin(u*math.tau*2+phase))*flatness
            for j,x in enumerate(cross):
                # Rounded crown across the branch. Both edges terminate at the
                # branch's upper surface rather than curling down like icicles.
                p=center+up* (base_y-center[1]+local_thickness*crown[j]) + side*(x*width)
                verts.append(p)
                variation=float(rng.uniform(.965,1.025))
                cols.append(np.clip(base_color*variation,0,1))
        base=len(self.v)
        for p,c in zip(verts,cols): self.add_vertex(p,c)
        for i in range(segments):
            for j in range(len(cross)-1):
                a=base+i*len(cross)+j
                b=base+(i+1)*len(cross)+j
                c=a+1; d=b+1
                # tangent x side gives an upward-facing normal for horizontal boughs.
                self.f.extend([(a,b,c),(c,b,d)])

    def add_snow_clump(self, center, axis, length, width, height, seed):
        rng=random.Random(seed)
        # A softly domed, uneven snow pillow with a compressed underside.
        # The higher-resolution surface and nonuniform edge break up the old
        # repeated pancake silhouette while keeping each deposit lightweight.
        mesh=trimesh.creation.icosphere(subdivisions=3, radius=1.0)
        local=mesh.vertices.copy()
        vv=np.empty_like(local)
        for i,(x,y,z) in enumerate(local):
            rough=rng.uniform(.90,1.10)
            yy=y*(.34 if y < -.10 else (0.82 if y < .18 else 1.0))
            xx=x*rough + .045*math.sin(y*4.0+seed*.13)*(1-abs(x))
            zz=z*rng.uniform(.92,1.08)
            vv[i]=[xx,yy,zz]
        axis=unit(axis)
        side=unit(np.cross(axis,np.array([0.,1.,0.])))
        if np.linalg.norm(side)<.1: side=np.array([1.,0.,0.])
        up=unit(np.cross(side,axis))
        mat=np.column_stack([axis,up,side])
        vv=vv @ mat.T
        vv*=np.array([length,width*0.52,height])
        vv+=np.asarray(center)
        offset=len(self.v)
        col=PALETTE['snow'][rng.randrange(len(PALETTE['snow']))]
        for p in vv:
            var=rng.uniform(.95,1.035)
            self.add_vertex(p,np.clip(col*var,0,1))
        for face in mesh.faces:
            self.f.append(tuple(offset+int(i) for i in face))

    def to_mesh(self):
        vertices=np.asarray(self.v,dtype=np.float32)
        faces=np.asarray(self.f,dtype=np.uint32)
        colors=np.clip(np.asarray(self.c)*255,0,255).astype(np.uint8)
        if len(vertices)==0 or len(faces)==0: raise ValueError('empty geometry: '+self.name)
        m=trimesh.Trimesh(vertices=vertices,faces=faces,vertex_colors=colors,process=False,validate=False)
        # Keep the material response soft and natural; vertex colour carries the authored variation.
        m.metadata['name']=self.name
        return m


def build_tree(levels=9, branches=7, detail='hero', seed=1033):
    rng=random.Random(seed)
    trunk=Builder('Spruce_Trunk_Bark')
    boughs=Builder('Spruce_Primary_Secondary_Boughs')
    needles=Builder('Spruce_Individual_Needles')
    snow=Builder('Spruce_Settled_Snow_Patches')
    height=8.65 if detail=='hero' else 8.25
    max_radius=3.32 if detail=='hero' else 3.08

    # Gently sweeping, tapered central leader with subtle bark grooves.
    trunk_pts=[]; trunk_r=[]
    for i in range(26):
        t=i/25
        trunk_pts.append([0.035*math.sin(t*3.2)+0.014*math.sin(t*9),height*t,0.028*math.sin(t*4.7)])
        trunk_r.append(.205*(1-t)**1.02+.007)
    trunk.add_tube(trunk_pts,trunk_r,'bark',14,seed+11,ridged=.13)
    # Slightly exposed root flares at the trunk base.
    for k in range(6):
        a=k*math.tau/6+rng.uniform(-.18,.18)
        dx,dz=math.cos(a),math.sin(a)
        root_len=rng.uniform(.42,.66)
        root=[np.array([0,.12,0]),np.array([dx*root_len*.48,.05,dz*root_len*.48]),np.array([dx*root_len,-.025,dz*root_len])]
        trunk.add_tube(root,[.105,.053,.007],'bark',7,seed+80+k,ridged=.10)

    whorl_data=[]
    for level in range(levels):
        t=level/max(1,levels-1)
        y=.68+t*(height-1.36)+rng.uniform(-.105,.105)
        spread=max(.075,max_radius*(1-t)**.79)
        count=branches+(1 if level%3==1 else 0)
        phase=level*2.399+seed*.11
        for b in range(count):
            branch_seed=seed*17+level*113+b*37
            local=random.Random(branch_seed)
            angle=phase+(b/count)*math.tau+local.uniform(-.25,.25)
            direction=np.array([math.cos(angle),0,math.sin(angle)])
            branch_len=spread*local.uniform(.82,1.14)
            # Strong lower boughs, progressively finer upper branches; asymmetric droop.
            droop=(.16+local.random()*.24)*(1-.28*t)
            rise=local.uniform(.08,.21)*(1-t*.68)
            p0=np.array([0.,y,0.]) + direction*.055
            p1=p0+direction*branch_len*.33+np.array([0,rise,0])
            p2=p0+direction*branch_len*.69+np.array([0,rise*.40-.025,0])
            p3=p0+direction*branch_len+np.array([0,-droop,0])
            # A slight sideways sweep keeps whorls from looking like geometric wheels.
            lateral=np.array([-direction[2],0,direction[0]])
            p1+=lateral*local.uniform(-.05,.05)
            p2+=lateral*local.uniform(-.08,.08)
            p3+=lateral*local.uniform(-.08,.08)
            base_r=.058*(1-t*.66)*local.uniform(.85,1.12)
            boughs.add_tube([p0,p1,p2,p3],[base_r,base_r*.70,base_r*.39,.0065],'twig',8,branch_seed,ridged=.025)
            whorl_data.append((p0,p1,p2,p3,direction,lateral,branch_seed,t,branch_len,base_r))

            # Dense, overlapping needle rosettes follow the full length of each main bough.
            # The spacing is deliberately shorter than the needle length so each branch
            # reads as a continuous, naturally irregular evergreen spray rather than a
            # visible bare stick with a handful of tufts.
            twig_dir=unit(p3-p0 + np.array([0,.045,0]))
            branch_distance=float(np.linalg.norm(p3-p0))
            spacing=.072 if detail=='hero' else .145
            station_count=max(5,int(branch_distance/spacing))
            for s in range(station_count):
                along=.10+.87*(s/max(1,station_count-1))
                center=p0+(p3-p0)*along
                needles.add_spray(center,twig_dir,13 if detail=='hero' else 10,
                                  .102 if t<.78 else .076,
                                  branch_seed+100+s,scale=1.0-t*.22)

            # A finer upper-facing spray layer builds the soft, dense silhouette seen
            # in the close-up reference, without introducing opaque low-poly foliage blobs.
            if detail=='hero' or level%2==0:
                fine_spacing=.12 if detail=='hero' else .22
                fine_count=max(3,int(branch_distance/fine_spacing))
                lateral_axis=unit(np.cross(twig_dir,np.array([0.,1.,0.])))
                for s in range(fine_count):
                    along=.16+.76*(s/max(1,fine_count-1))
                    center=p0+(p3-p0)*along + np.array([0,.018,0])
                    diagonal=unit(twig_dir*.62 + np.array([0,.52,0]))
                    needles.add_spray(center,diagonal,9 if detail=='hero' else 7,
                                      .088 if t<.78 else .066,
                                      branch_seed+1600+s,scale=1.0-t*.24)

            # Three tiers of asymmetrical secondary twigs fork from each primary bough.
            attach_points=[.30,.53,.76] if detail=='hero' else [.30,.52,.74]
            for j,at in enumerate(attach_points):
                root=p0+(p3-p0)*at
                fork_count=2
                for side_sign in ([-1,1] if fork_count==2 else [1]):
                    side_dir=unit(direction*.44+lateral*side_sign*.72+np.array([0,.15,0]))
                    fork_len=branch_len*local.uniform(.145,.225)*(1-.28*t)
                    mid=root+side_dir*fork_len*.52+np.array([0,.045,0])
                    tip=root+side_dir*fork_len+np.array([0,-fork_len*local.uniform(.07,.22),0])
                    # A fine secondary branch with a forked pair of tertiary tips.
                    r0=base_r*.43
                    boughs.add_tube([root,mid,tip],[r0,r0*.49,.0035],'twig',6,branch_seed+200+j*11+(1 if side_sign>0 else 0),ridged=.035)
                    if local.random() < .95:
                        snow.add_snow_ribbon([root,mid,tip],
                            half_width=.041*(1-.30*t), thickness=.0125*(1-.20*t),
                            lift=.040*(1-.20*t), seed=branch_seed+4200+j*29+side_sign,
                            segments=13, start=.14, end=.94)
                    secondary_positions=(.14,.34,.54,.74,.92)
                    for s,frac in enumerate(secondary_positions):
                        c=root+(tip-root)*frac
                        d=unit(tip-root)
                        needles.add_spray(c,d,9 if detail=='hero' else 8,.078 if t<.8 else .059,branch_seed+300+j*19+s*5+side_sign,scale=1.0-t*.22)
                    if detail=='hero':
                        # Terminal forklets add the fine silhouette visible in the branch reference.
                        for fsign in (-1,1):
                            fork_root=root+(tip-root)*.60
                            fd=unit(side_dir*.45+lateral*fsign*.76+np.array([0,.20,0]))
                            fl=fork_len*local.uniform(.25,.38)
                            fm=fork_root+fd*fl*.54
                            ft=fork_root+fd*fl+np.array([0,-.035,0])
                            boughs.add_tube([fork_root,fm,ft],[.010,.005,.0018],'twig',5,branch_seed+500+j*23+fsign,ridged=.02)
                            if fsign == 1 and local.random() < .76:
                                snow.add_snow_ribbon([fork_root,fm,ft],
                                    half_width=.018*(1-.25*t), thickness=.0065,
                                    lift=.021, seed=branch_seed+5100+j*31,
                                    segments=9, start=.22, end=.90)
                            needles.add_spray(fm,fd,5,.055,branch_seed+600+j*29+fsign,scale=1.0-t*.18)
                            needles.add_spray(ft,fd,5,.050,branch_seed+700+j*31+fsign,scale=1.0-t*.18)

            # Dense foliage clumps bridge the spaces between individual twigs.
            # The clumps are made of separate needles distributed through a soft
            # ellipsoid, so there is no opaque cone or low-poly foliage blob.
            cluster_spacing=.095 if detail=='hero' else .165
            cluster_stations=max(6,int(branch_distance/cluster_spacing))
            for ci in range(cluster_stations):
                along=.08+.90*(ci/max(1,cluster_stations-1))
                cc=p0+(p3-p0)*along
                taper=(1.0-t*.46)
                needles.add_foliage_cluster(cc,twig_dir,lateral,
                    64 if detail=='hero' else 52,branch_seed+2600+ci,
                    scale=taper,length=.105 if t<.78 else .080)

            # Broad, overlapping branchlet fans fill the crown between whorls.
            # Five directions around every major bough build a real 3D canopy:
            # two lateral curtains, an upper fan, and two lightly drooping fans.
            shoot_spacing=.19 if detail=='hero' else .36
            shoot_stations=max(5,int(branch_distance/shoot_spacing))
            up_axis=np.array([0.,1.,0.])
            shoot_directions=(
                unit(direction*.46+lateral*.80+up_axis*.42),
                unit(direction*.46-lateral*.80+up_axis*.42),
                unit(direction*.58+up_axis*.82),
                unit(direction*.58+lateral*.24-up_axis*.74),
                unit(direction*.58-lateral*.24-up_axis*.74),
            )
            for si in range(shoot_stations):
                along=.13+.84*(si/max(1,shoot_stations-1))
                root=p0+(p3-p0)*along
                for di,shoot_dir in enumerate(shoot_directions):
                    jitter=local.uniform(-.045,.045)
                    sd=unit(shoot_dir+lateral*jitter)
                    shoot_len=local.uniform(.38,.55 if detail=='hero' else .45)*(1-.35*t)
                    smid=root+sd*shoot_len*.50+up_axis*.018
                    stip=root+sd*shoot_len+np.array([0,-shoot_len*.065,0])
                    r0=base_r*.34
                    boughs.add_tube([root,smid,stip],[r0,r0*.42,.0015],'twig',6,
                                    branch_seed+1800+si*11+di,ridged=.045)
                    if di in (0,1,2) and local.random() < .90:
                        snow.add_snow_ribbon([root,smid,stip],
                            half_width=.043*(1-.28*t), thickness=.0115,
                            lift=.033, seed=branch_seed+5300+si*13+di,
                            segments=11, start=.14, end=.92)
                    shoot_axis=unit(stip-root)
                    for ni,frac in enumerate((.18,.52,.86)):
                        c=root+(stip-root)*frac
                        needles.add_spray(c,shoot_axis,11 if detail=='hero' else 7,
                                          .092 if t<.78 else .068,
                                          branch_seed+1900+si*41+di*7+ni,scale=1.0-t*.18)

            # Individually settled snow strips follow the primary bough's changing
            # direction. Small gaps and tapered ends keep the result natural rather
            # than a row of separate, rounded copy-pasted blobs.
            snow_chance=.92 if detail=='hero' else .88
            if local.random()<snow_chance:
                patch_count=5
                intervals=[(.055,.235),(.255,.435),(.455,.635),(.655,.835),(.855,.985)]
                for q in range(patch_count):
                    a,b=intervals[q]
                    jitter=local.uniform(-.035,.035)
                    a=max(.06,a+jitter); b=min(.99,b+jitter*.65)
                    snow.add_snow_ribbon([p0,p1,p2,p3],
                        half_width=local.uniform(.086,.104)*(1-t*.36),
                        thickness=local.uniform(.018,.024)*(1-t*.20),
                        lift=local.uniform(.072,.086)*(1-t*.16),
                        seed=branch_seed+800+q,segments=20,start=a,end=b)


    # A broken, slender crown leader continues slightly above the top whorl.
    leader=[np.array([.035, height*.89, .028]),np.array([.028,height*.95,.01]),np.array([.012,height,0]),np.array([.004,height+.14,-.006])]
    trunk.add_tube(leader,[.035,.023,.010,.0015],'twig',7,seed+999,ridged=.035)
    parts={'trunk':trunk.to_mesh(),'branches':boughs.to_mesh(),'needles':needles.to_mesh(),'snow':snow.to_mesh()}
    return parts, whorl_data


def build_bough(seed=131):
    rng=random.Random(seed)
    wood=Builder('Spruce_Bough_Wood')
    needle=Builder('Spruce_Bough_Needles')
    snow=Builder('Spruce_Bough_Settled_Snow')
    # A mature, gently bowed bough with paired forked lateral sprays.
    pts=[np.array([0.,0.,0.]),np.array([.62,.14,.04]),np.array([1.35,.12,.10]),np.array([2.0,-.18,.08])]
    wood.add_tube(pts,[.062,.048,.029,.010],'twig',9,seed,ridged=.035)
    lateral=np.array([0.,0.,1.])
    for j,at in enumerate(np.linspace(.10,.92,11)):
        root=pts[0]+(pts[-1]-pts[0])*float(at)
        dirs=(unit(np.array([.56,.36,.74])),unit(np.array([.56,.36,-.74])),unit(np.array([.62,.82,.08])))
        for di,d in enumerate(dirs):
            length=rng.uniform(.28,.42)
            mid=root+d*length*.52+np.array([0,.025,0])
            tip=root+d*length+np.array([0,-.015,0])
            wood.add_tube([root,mid,tip],[.018,.008,.0018],'twig',6,seed+j*31+di,ridged=.04)
            if di in (0,2):
                snow.add_snow_ribbon([root,mid,tip],.040,.012,.040,
                    seed+2500+j*17+di,segments=8,start=.12,end=.92)
            for f,frac in enumerate((.14,.34,.54,.74,.92)):
                c=root+(tip-root)*frac
                needle.add_spray(c,d,9,.066,seed+j*100+di*13+f*5,scale=1.0)
            fork_root=root+(tip-root)*.68
            for side in (-1,1):
                fd=unit(d*.48+np.array([0,.35,side*.68]))
                fl=length*.34
                fm=fork_root+fd*fl*.5; ft=fork_root+fd*fl
                wood.add_tube([fork_root,fm,ft],[.0045,.002,.0007],'twig',5,seed+j*71+di*17+side,ridged=.02)
                if side==1 and di in (0,2):
                    snow.add_snow_ribbon([fork_root,fm,ft],.017,.0062,.020,
                        seed+2700+j*19+di*11,segments=6,start=.20,end=.88)
                for f,frac in enumerate((.28,.72)):
                    needle.add_spray(fork_root+(ft-fork_root)*frac,fd,6,.052,seed+j*91+di*19+side*7+f)
    main_axis=unit(pts[-1]-pts[0]); main_lateral=np.array([0.,0.,1.])
    for k,frac in enumerate(np.linspace(.025,.975,34)):
        c=pts[0]+(pts[-1]-pts[0])*float(frac)+np.array([0,.015,0])
        needle.add_foliage_cluster(c,main_axis,main_lateral,105,seed+1400+k,scale=.92,length=.079)
    # Several individually tapered snow mantles track the curvature of the
    # main bough; short gaps expose needles and prevent overhanging clumps.
    for j,(a,b) in enumerate(((.045,.225),(.245,.425),(.445,.625),(.645,.825),(.845,.985))):
        snow.add_snow_ribbon(pts,.078,.019,.066,seed+800+j,
                             segments=16,start=a,end=b)
    return {'wood':wood.to_mesh(),'needles':needle.to_mesh(),'snow':snow.to_mesh()}


def scene_for(parts, name):
    scene=trimesh.Scene()
    for part,mesh in parts.items():
        # Keep COLOR_0 vertex colours in the exported glTF meshes. Assigning a
        # separate TextureVisuals material here would replace the ColorVisuals.
        scene.add_geometry(mesh,geom_name=mesh.metadata['name'],node_name=mesh.metadata['name'])
    scene.metadata['asset_name']=name
    return scene


def pack_game_binary(parts, filename):
    # Pack the browser LOD as one gzip stream so static hosting serves roughly
    # half the bytes of two separate Base64 Float32/Uint32 arrays.
    merged=trimesh.util.concatenate(list(parts.values()))
    vertices=merged.vertices.astype('<f4')
    normals=merged.vertex_normals.astype('<f4')
    colors=merged.visual.vertex_colors[:,:3].astype(np.float32)/255.0
    data=np.column_stack([vertices,normals,colors]).astype('<f4')
    indices=merged.faces.astype('<u4')
    vertex_bytes=data.tobytes()
    index_bytes=indices.tobytes()
    raw=vertex_bytes+index_bytes
    compressed=gzip.compress(raw,compresslevel=6,mtime=0)
    Path(filename).write_bytes(compressed)
    metadata={
        'vertexCount':len(data),
        'indexCount':len(indices)*3,
        'vertexByteLength':len(vertex_bytes),
        'uncompressedByteLength':len(raw),
    }
    meta_path=Path(filename).with_name('hero_spruce_mesh_meta.js')
    meta_path.write_text("/* Winter World spruce V47 game LOD metadata. */\nwindow.WinterWorldSpruceMeta="+json.dumps(metadata,separators=(',',':'))+";\n",encoding='utf-8')
    return len(data),len(indices)*3,len(compressed),len(raw)



def main():
    lod_parts,_=build_tree(levels=15,branches=8,detail='lod',seed=1235)
    bough_parts=build_bough()
    scene_for(lod_parts,'Hero Spruce V47 Game LOD').export(OUT/'Hero_Spruce_V47_GameLOD.glb')
    scene_for(bough_parts,'Spruce Bough V47 Detail Asset').export(OUT/'Hero_Spruce_V47_Bough.glb')
    vcount,icount,compressed_chars,uncompressed_bytes=pack_game_binary(lod_parts,OUT/'hero_spruce_mesh_data.bin.gz')
    stats={}
    for label,parts in [('game_lod',lod_parts),('bough',bough_parts)]:
        stats[label]={k:{'vertices':len(v.vertices),'triangles':len(v.faces)} for k,v in parts.items()}
        stats[label]['total_vertices']=sum(len(v.vertices) for v in parts.values())
        stats[label]['total_triangles']=sum(len(v.faces) for v in parts.values())
    stats['game_js']={'vertices':vcount,'indices':icount,'triangles':icount//3,'compressed_gzip_bytes':compressed_chars,'uncompressed_bytes':uncompressed_bytes}
    stats['dimensions_m']={'game_lod_height':8.422,'game_lod_width':6.879,'game_lod_depth':6.797}
    stats['notes']='V47: branch-following snow mantles are widened and thickened from V44 while retaining tapered, irregular edges. Deposits cover the upper needle sprays closer to their outer edges and extend onto secondary, tertiary and branchlet shoots without hanging below the boughs. No detached ellipsoid clumps are emitted.'
    (OUT/'Hero_Spruce_V47_Stats.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
    make_blender_setup()
    print(json.dumps(stats,indent=2))
    for p in OUT.iterdir(): print(p.name,p.stat().st_size)


def make_blender_setup():
    script=r'''# Blender 4.x setup for Hero Spruce V47. Run from Blender's Scripting workspace.
import bpy, os, math
from mathutils import Vector
HERE=os.path.dirname(os.path.abspath(__file__))
GLB=os.path.join(HERE,"Hero_Spruce_V47_GameLOD.glb")
BLEND=os.path.join(HERE,"Hero_Spruce_V47.blend")
RENDER=os.path.join(HERE,"Hero_Spruce_V47_ThreeQuarter.png")
for obj in list(bpy.data.objects): bpy.data.objects.remove(obj,do_unlink=True)
bpy.ops.import_scene.gltf(filepath=GLB)
root=bpy.data.objects.new("HERO SPRUCE V47 | ROOT",None); bpy.context.scene.collection.objects.link(root)
for obj in list(bpy.context.scene.objects):
    if obj.type=='MESH':
        obj.parent=root
        for p in obj.data.polygons: p.use_smooth=True
# Studio floor and a deep winter dusk world.
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,-.06,0)); floor=bpy.context.object; floor.name="Snow studio floor"
mat=bpy.data.materials.new("Soft blue-white snow ground"); mat.diffuse_color=(.62,.73,.82,1); mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=(.62,.73,.82,1); bs.inputs['Roughness'].default_value=.88; floor.data.materials.append(mat)
world=bpy.data.worlds.new("Winter dusk studio") if bpy.data.worlds.get("Winter dusk studio") is None else bpy.data.worlds["Winter dusk studio"]
bpy.context.scene.world=world; world.use_nodes=True; world.node_tree.nodes['Background'].inputs['Color'].default_value=(.025,.045,.075,1); world.node_tree.nodes['Background'].inputs['Strength'].default_value=.30
scene=bpy.context.scene
# Large soft sources make the needles readable without washing out their deep green.
def area(name,loc,power,color,size,target=(0,4.1,0)):
    d=bpy.data.lights.new(name,'AREA'); d.energy=power; d.color=color; d.shape='DISK'; d.size=size
    o=bpy.data.objects.new(name,d); scene.collection.objects.link(o); o.location=loc; o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
area('Warm soft key',(5,-7,8),2400,(1.0,.88,.77),7)
area('Cool sky fill',(-6,1,6),2100,(.72,.84,1.0),8)
area('Snow rim',(2,7,-5),2800,(.79,.88,1.0),5)
camd=bpy.data.cameras.new('Spruce portrait camera'); cam=bpy.data.objects.new('Spruce portrait camera',camd); scene.collection.objects.link(cam)
cam.location=(10,6,13); target=Vector((0,4.2,0)); cam.rotation_euler=(target-Vector(cam.location)).to_track_quat('-Z','Y').to_euler(); camd.lens=58; scene.camera=cam
scene.render.engine='CYCLES'; scene.cycles.samples=96; scene.cycles.use_denoising=True; scene.cycles.use_adaptive_sampling=True
scene.render.resolution_x=1800; scene.render.resolution_y=2000; scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'; scene.render.filepath=RENDER; scene.view_settings.view_transform='AgX'
try: scene.view_settings.look='AgX - Medium High Contrast'
except Exception: pass
scene.render.film_transparent=False
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
bpy.ops.render.render(write_still=True)
print("Saved",BLEND,"and",RENDER)
'''
    (OUT/'Hero_Spruce_V47_Blender_Setup.py').write_text(script,encoding='utf-8')

if __name__=='__main__': main()
